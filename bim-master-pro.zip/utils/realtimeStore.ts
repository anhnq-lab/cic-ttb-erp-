
import { supabase } from './supabaseClient';
import { Task, TaskStatus } from '../types';
import { TASKS } from '../constants'; // Fallback data if needed

export const realtimeStore = {
  // 1. Get Tasks (Async from DB)
  getTasks: async (projectId: string): Promise<Task[]> => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .select('*')
        .eq('project_id', projectId)
        .order('created_at', { ascending: true });

      if (error) {
        console.error('Error fetching tasks:', error);
        return [];
      }

      // Map DB structure to Frontend Task Interface if necessary
      // Assuming DB columns match Task interface mostly
      return data as Task[];
    } catch (e) {
      console.error(e);
      return [];
    }
  },

  // 2. Update Task Status (Write to DB)
  updateTaskStatus: async (taskId: string, newStatus: TaskStatus) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .update({ status: newStatus })
        .eq('id', taskId);

      if (error) throw error;
    } catch (e) {
      console.error('Error updating task:', e);
    }
  },

  // 3. Subscribe to Realtime Changes
  subscribe: (projectId: string, callback: () => void) => {
    const channel = supabase
      .channel('public:tasks') // Channel name
      .on(
        'postgres_changes',
        {
          event: '*', // Listen to INSERT, UPDATE, DELETE
          schema: 'public',
          table: 'tasks',
          filter: `project_id=eq.${projectId}`, // Only listen for this project
        },
        (payload) => {
          console.log('Realtime Change received!', payload);
          callback(); // Trigger UI reload
        }
      )
      .subscribe();

    return channel;
  },

  // 4. Unsubscribe
  unsubscribe: (channel: any) => {
    if (channel) {
      supabase.removeChannel(channel);
    }
  }
};
