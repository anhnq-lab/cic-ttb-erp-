
import { createClient } from '@supabase/supabase-js';

// Thay thế bằng URL và Key thực tế của bạn từ Supabase Dashboard -> Settings -> API
const SUPABASE_URL = process.env.REACT_APP_SUPABASE_URL || 'https://your-project-url.supabase.co';
const SUPABASE_ANON_KEY = process.env.REACT_APP_SUPABASE_ANON_KEY || 'your-anon-key';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
