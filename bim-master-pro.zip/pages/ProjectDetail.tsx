
import React, { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { PROJECTS, CONTRACTS } from '../constants';
import { Contract, TaskStatus, TaskPriority, Task } from '../types';
import { realtimeStore } from '../utils/realtimeStore'; // Import Realtime Store
import Header from '../components/Header';
import { 
  ArrowLeft, Calendar, DollarSign, Users, CheckSquare, 
  Clock, FileText, Layers, Table, List, Shield, Landmark, ScrollText,
  MapPin, Scale, Briefcase, Info, BadgeCheck, Gavel, TrendingUp, CreditCard,
  MessageSquareWarning, Package, X, ChevronRight, FileCheck,
  Columns, Filter, Plus, User as UserIcon, Building2, Award, Ruler,
  ArrowRightCircle, ArrowLeftCircle, Loader
} from 'lucide-react';
import { 
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
} from 'recharts';

// --- RACI ROLES & DATA ---
const RACI_ROLES = ['GĐTT', 'PGĐTT', 'QLDA', 'QL BIM', 'ĐPBM', 'TNDH', 'NDH'];
const RACI_STATE_BUDGET = [
  { phase: '1. Xúc tiến Dự án', tasks: [
    { name: '1.1 Thuyết trình khách hàng', roles: { 'GĐTT': 'I/C', 'PGĐTT': 'C', 'QLDA': 'C', 'QL BIM': 'R' } },
    { name: '1.2 Liên hệ khách hàng nắm bắt thông tin định kỳ', roles: { 'QLDA': 'R' } },
    { name: '1.4 Thu thập dữ liệu đầu vào báo giá', roles: { 'GĐTT': 'I', 'PGĐTT': 'I', 'QLDA': 'R' } }
  ]},
  { phase: '4. Triển khai trình thẩm định', tasks: [
    { name: '4.1 Dựng mô hình trình thẩm định', roles: { 'QLDA': 'A', 'QL BIM': 'A', 'ĐPBM': 'A', 'TNDH': 'R', 'NDH': 'R' } },
    { name: '4.4 Tập hợp hồ sơ trình thẩm định', roles: { 'GĐTT': 'A', 'QLDA': 'R', 'QL BIM': 'C' } }
  ]}
];

// --- WORKFLOW DATA DEFINITIONS ---
interface WorkflowStep {
  step: number;
  title: string;
  role: string;
  description: string;
  output: string;
}

const TASK_WORKFLOWS: Record<string, WorkflowStep[]> = {
  '1.1 Thuyết trình khách hàng': [
    { step: 1, title: 'Tiếp nhận yêu cầu', role: 'QL BIM', description: 'Nhận yêu cầu demo/thuyết trình từ BGĐ hoặc Khách hàng. Xác định phạm vi và mục tiêu.', output: 'Email xác nhận' },
    { step: 2, title: 'Chuẩn bị tài liệu & Slide', role: 'QL BIM', description: 'Soạn thảo slide giới thiệu năng lực, giải pháp kỹ thuật và kế hoạch sơ bộ.', output: 'File Slide .pptx' },
    { step: 3, title: 'Review nội bộ', role: 'GĐTT / PGĐTT', description: 'Đánh giá nội dung, chiến lược tiếp cận và chỉnh sửa nếu cần.', output: 'Slide hoàn thiện' },
    { step: 4, title: 'Thuyết trình', role: 'QL BIM / GĐTT', description: 'Trình bày trực tiếp với khách hàng, demo mô hình mẫu (nếu có).', output: 'Biên bản cuộc họp' },
    { step: 5, title: 'Ghi nhận phản hồi', role: 'QL BIM', description: 'Ghi chép các yêu cầu điều chỉnh hoặc mối quan tâm của khách hàng để phục vụ báo giá.', output: 'Report Q&A' }
  ],
  '4.1 Dựng mô hình trình thẩm định': [
    { step: 1, title: 'Nghiên cứu bản vẽ', role: 'NDH', description: 'Đọc hiểu bản vẽ 2D, phát hiện các sai sót/thiếu thông tin ban đầu (RFI).', output: 'List RFI (nếu có)' },
    { step: 2, title: 'Dựng hình (Modeling)', role: 'NDH', description: 'Triển khai dựng mô hình 3D theo tiêu chuẩn BEP và LOD yêu cầu.', output: 'File Revit (.rvt)' },
    { step: 3, title: 'Tự kiểm tra (Self-Check)', role: 'NDH', description: 'Kiểm tra va chạm sơ bộ và tính đầy đủ của thông tin phi hình học.', output: 'Checklist cá nhân' },
    { step: 4, title: 'Kiểm soát chất lượng (QA/QC)', role: 'TNDH / ĐPBM', description: 'Kiểm tra mô hình theo Checklist QA/QC của dự án. Yêu cầu sửa lỗi.', output: 'Report QA/QC' },
    { step: 5, title: 'Đệ trình', role: 'QL BIM', description: 'Đóng gói file, upload lên CDE và gửi thông báo cho CĐT.', output: 'Transmittal' }
  ],
  '4.4 Tập hợp hồ sơ trình thẩm định': [
    { step: 1, title: 'Kiểm tra danh mục hồ sơ', role: 'QL BIM', description: 'Rà soát danh mục các file cần nộp theo hợp đồng/giai đoạn.', output: 'Master List' },
    { step: 2, title: 'Xuất hồ sơ từ mô hình', role: 'QL BIM', description: 'Xuất bản vẽ PDF, file IFC, NWC và các báo cáo khối lượng.', output: 'Bộ hồ sơ số' },
    { step: 3, title: 'Ký số / Đóng dấu', role: 'GĐTT', description: 'Thực hiện quy trình ký duyệt nội bộ và đóng dấu pháp nhân (nếu cần).', output: 'Hồ sơ pháp lý' },
    { step: 4, title: 'Bàn giao', role: 'QLDA', description: 'Gửi hồ sơ cứng hoặc link tải hồ sơ mềm cho đơn vị thẩm định.', output: 'Biên bản bàn giao' }
  ]
};

// --- HELPER FUNCTIONS ---
const formatCurrency = (value: number | undefined) => {
  if (value === undefined || isNaN(value)) return '0 ₫';
  return new Intl.NumberFormat('vi-VN', { style: 'currency', currency: 'VND' }).format(value);
};

// Map sequence of statuses for movement
const STATUS_SEQUENCE = [
    TaskStatus.OPEN,
    TaskStatus.S0,
    TaskStatus.S1,
    TaskStatus.S3,
    TaskStatus.S4,
    TaskStatus.S6,
    TaskStatus.COMPLETED
];

// --- COMPONENTS ---

const KanbanCard: React.FC<{ task: Task, onMove: (id: string, newStatus: TaskStatus) => void }> = ({ task, onMove }) => {
    // Map status to colors
    const getStatusColor = (status: TaskStatus) => {
        switch(status) {
            case TaskStatus.S0: return 'bg-blue-50 text-blue-700 border-blue-200';
            case TaskStatus.S1: return 'bg-indigo-50 text-indigo-700 border-indigo-200';
            case TaskStatus.S3: return 'bg-purple-50 text-purple-700 border-purple-200';
            case TaskStatus.S4: return 'bg-amber-50 text-amber-700 border-amber-200';
            case TaskStatus.S6: return 'bg-cyan-50 text-cyan-700 border-cyan-200';
            case TaskStatus.COMPLETED: return 'bg-emerald-50 text-emerald-700 border-emerald-200';
            default: return 'bg-gray-50 text-gray-700 border-gray-200';
        }
    };

    const currentStatusIdx = STATUS_SEQUENCE.indexOf(task.status);
    const prevStatus = currentStatusIdx > 0 ? STATUS_SEQUENCE[currentStatusIdx - 1] : null;
    const nextStatus = currentStatusIdx < STATUS_SEQUENCE.length - 1 ? STATUS_SEQUENCE[currentStatusIdx + 1] : null;

    return (
        <div className="bg-white p-3 rounded-lg border border-gray-200 shadow-sm hover:shadow-md transition-all cursor-pointer group relative">
            <div className="flex justify-between items-start mb-2">
                <span className="text-[10px] font-mono font-bold text-gray-400 bg-gray-50 px-1.5 py-0.5 rounded border border-gray-100">
                    {task.code}
                </span>
                {task.priority === TaskPriority.HIGH && (
                    <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse"></span>
                )}
            </div>
            <h4 className="text-sm font-semibold text-slate-800 mb-2 leading-tight group-hover:text-orange-600 transition-colors">
                {task.name}
            </h4>
            
            <div className="flex flex-wrap gap-1 mb-3">
                {task.tags?.map((tag, i) => (
                    <span key={i} className="text-[10px] bg-slate-100 text-slate-500 px-1.5 py-0.5 rounded">
                        {tag}
                    </span>
                ))}
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-gray-50">
                <div className="flex items-center gap-1.5" title={task.assignee?.name}>
                    {task.assignee?.avatar && <img src={task.assignee.avatar} alt="" className="w-5 h-5 rounded-full border border-gray-200" />}
                    <span className="text-xs text-gray-500 font-medium truncate max-w-[80px]">{task.assignee?.name || 'Unassigned'}</span>
                </div>
                
                {/* INTERACTIVE CONTROLS */}
                <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity absolute right-2 bottom-2 bg-white pl-2">
                    {prevStatus && (
                        <button 
                            onClick={(e) => { e.stopPropagation(); onMove(task.id, prevStatus); }}
                            className="p-1 hover:bg-gray-100 rounded text-gray-400 hover:text-gray-600" title="Quay lại bước trước"
                        >
                            <ArrowLeftCircle size={16} />
                        </button>
                    )}
                    {nextStatus && (
                        <button 
                            onClick={(e) => { e.stopPropagation(); onMove(task.id, nextStatus); }}
                            className="p-1 hover:bg-emerald-50 rounded text-emerald-500 hover:text-emerald-700" title="Chuyển bước tiếp theo"
                        >
                            <ArrowRightCircle size={16} />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

const KanbanColumn: React.FC<{ title: string, status: string, tasks?: Task[], count: number, onMove: (id: string, s: TaskStatus) => void }> = ({ title, status, tasks = [], count, onMove }) => (
    <div className="flex-shrink-0 w-80 flex flex-col h-full bg-gray-50/50 rounded-xl border border-gray-200/60">
        <div className="p-3 flex items-center justify-between border-b border-gray-100 bg-gray-50 rounded-t-xl">
            <div className="flex items-center gap-2">
                <div className={`w-2 h-2 rounded-full 
                    ${status.includes('S0') ? 'bg-blue-500' : 
                      status.includes('S6') ? 'bg-emerald-500' : 
                      status.includes('S4') ? 'bg-amber-500' : 'bg-slate-400'}`}>
                </div>
                <h3 className="text-xs font-bold text-slate-700 uppercase tracking-wide">{title}</h3>
            </div>
            <span className="text-xs font-bold text-gray-400 bg-white px-2 py-0.5 rounded-full border border-gray-200 shadow-sm">{count}</span>
        </div>
        <div className="flex-1 p-2 overflow-y-auto custom-scrollbar space-y-2">
            {tasks && tasks.length > 0 ? (
                tasks.map(task => <KanbanCard key={task.id} task={task} onMove={onMove} />)
            ) : (
                <div className="h-24 border-2 border-dashed border-gray-200 rounded-lg flex items-center justify-center text-xs text-gray-400">
                    Không có công việc
                </div>
            )}
        </div>
    </div>
);

// --- EXISTING COMPONENTS ---
const HighlightStat = ({ label, value, subValue, icon: Icon, colorClass }: { label: string, value: string, subValue?: string, icon: any, colorClass: string }) => (
    <div className="bg-white p-5 rounded-2xl border border-gray-100 shadow-sm flex items-center gap-4 transition-all hover:shadow-md">
        <div className={`w-12 h-12 rounded-xl ${colorClass} flex items-center justify-center shrink-0`}>
            <Icon size={24} />
        </div>
        <div className="overflow-hidden">
            <p className="text-[10px] text-gray-400 uppercase font-black tracking-widest mb-0.5">{label}</p>
            <p className="text-lg font-black text-slate-800 truncate">{value}</p>
            {subValue && <p className="text-[10px] font-bold text-gray-500 truncate">{subValue}</p>}
        </div>
    </div>
);

const RaciBadge = ({ value }: { value?: string }) => {
  if (!value) return null;
  let colorClass = "text-gray-400";
  let bgClass = "bg-gray-50";
  if (value.includes('R')) { colorClass = "text-rose-700"; bgClass = "bg-rose-50 border-rose-100"; }
  else if (value.includes('A')) { colorClass = "text-amber-700"; bgClass = "bg-amber-50 border-amber-100"; }
  else if (value.includes('C')) { colorClass = "text-blue-700"; bgClass = "bg-blue-50 border-blue-100"; }
  else if (value.includes('I')) { colorClass = "text-slate-600"; bgClass = "bg-slate-100 border-slate-200"; }
  return (
    <div className={`w-8 h-8 flex items-center justify-center rounded-lg border font-bold text-xs mx-auto shadow-sm ${bgClass} ${colorClass}`}>
      {value}
    </div>
  );
};

const SectionTitle = ({ title, icon: Icon }: { title: string, icon: any }) => (
    <div className="flex items-center gap-2 mb-6 pb-2 border-b border-gray-100">
        <div className="w-9 h-9 rounded-xl bg-orange-50 flex items-center justify-center text-orange-600 shadow-sm">
            <Icon size={20} />
        </div>
        <h4 className="font-bold text-gray-800 text-base uppercase tracking-tight">{title}</h4>
    </div>
);

const InfoItem = ({ label, value, icon: Icon }: { label: string, value: string | number | undefined, icon?: any }) => (
    <div className="flex flex-col gap-1">
        <span className="text-[10px] uppercase font-bold text-gray-400 tracking-wider flex items-center gap-1">
            {Icon && <Icon size={10} />} {label}
        </span>
        <span className="text-sm font-medium text-gray-800 leading-snug">{value || 'N/A'}</span>
    </div>
);

const WorkflowModal = ({ taskName, steps, onClose }: { taskName: string, steps: WorkflowStep[], onClose: () => void }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] overflow-hidden flex flex-col animate-fade-in-up">
      <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
        <div>
          <h3 className="text-lg font-bold text-slate-800">{taskName}</h3>
          <p className="text-xs text-gray-500">Quy trình thực hiện chuẩn</p>
        </div>
        <button onClick={onClose} className="p-2 hover:bg-gray-200 rounded-full text-gray-500 transition-colors">
          <X size={20} />
        </button>
      </div>
      
      <div className="overflow-y-auto p-6 custom-scrollbar">
        <div className="relative">
          <div className="absolute left-6 top-4 bottom-4 w-0.5 bg-gray-200"></div>
          
          <div className="space-y-6">
            {steps.map((step, idx) => (
              <div key={idx} className="relative flex gap-6">
                <div className="w-12 h-12 rounded-full bg-orange-600 text-white flex items-center justify-center font-bold text-lg shadow-md shrink-0 z-10 border-4 border-white">
                  {step.step}
                </div>
                <div className="flex-1 bg-white border border-gray-100 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="font-bold text-slate-800 text-sm">{step.title}</h4>
                    <span className="text-[10px] font-bold bg-slate-100 text-slate-600 px-2 py-1 rounded uppercase tracking-wider">
                      {step.role}
                    </span>
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mb-3">{step.description}</p>
                  <div className="flex items-center gap-2 pt-3 border-t border-gray-50">
                    <FileCheck size={14} className="text-emerald-500" />
                    <span className="text-xs font-medium text-emerald-700">Đầu ra: {step.output}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      <div className="p-4 border-t border-gray-100 bg-gray-50 text-center">
        <button onClick={onClose} className="px-6 py-2 bg-white border border-gray-300 text-gray-700 font-medium rounded-lg hover:bg-gray-100 text-sm">
          Đóng quy trình
        </button>
      </div>
    </div>
  </div>
);

const ContractCard: React.FC<{ contract: Contract }> = ({ contract }) => (
    <div className="space-y-6">
        <div className="bg-gradient-to-r from-slate-800 to-slate-900 rounded-2xl p-6 text-white shadow-xl">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <span className="bg-orange-500/20 text-orange-300 text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-widest mb-2 inline-block border border-orange-500/30">
                        {contract.contractType}
                    </span>
                    <h3 className="text-xl font-bold mb-1 tracking-tight">{contract.code}</h3>
                    <p className="text-slate-400 text-sm">{contract.packageName}</p>
                </div>
                <div className="text-left md:text-right">
                    <p className="text-[10px] text-slate-400 uppercase font-bold mb-1">Tổng giá trị hợp đồng</p>
                    <p className="text-3xl font-black text-orange-400">
                        {formatCurrency(contract.totalValue)}
                    </p>
                </div>
            </div>
        </div>
        {/* ... (rest of contract card) ... */}
    </div>
);

const ProjectDetail = () => {
  const { id } = useParams<{ id: string }>();
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedWorkflow, setSelectedWorkflow] = useState<{name: string, steps: WorkflowStep[]} | null>(null);
  const [viewMode, setViewMode] = useState<'board' | 'list'>('board');
  
  // --- REALTIME STATE ---
  const [tasks, setTasks] = useState<Task[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  // --- EFFECT: LOAD TASKS & SUBSCRIBE ---
  useEffect(() => {
    if (id) {
        const fetchAndSubscribe = async () => {
            setIsSyncing(true);
            
            // 1. Initial Load (Async now)
            const loadedTasks = await realtimeStore.getTasks(id);
            setTasks(loadedTasks);
            setIsSyncing(false);

            // 2. Subscribe to realtime updates
            const channel = realtimeStore.subscribe(id, async () => {
                // When change happens, fetch fresh data
                const freshTasks = await realtimeStore.getTasks(id);
                setTasks(freshTasks);
            });

            return channel;
        };

        const channelPromise = fetchAndSubscribe();

        // Cleanup
        return () => {
            channelPromise.then(channel => realtimeStore.unsubscribe(channel));
        };
    }
  }, [id]);

  // --- HANDLE MOVE TASK ---
  const handleTaskMove = async (taskId: string, newStatus: TaskStatus) => {
      // Optimistic UI update
      setTasks(prev => prev.map(t => t.id === taskId ? { ...t, status: newStatus } : t));
      // Call Service (Async)
      await realtimeStore.updateTaskStatus(taskId, newStatus);
  };
  
  const project = PROJECTS.find(p => p.id === id);
  const contracts = CONTRACTS.filter(c => 
    (project?.name && c.projectName.includes('Nhi đồng 1')) || 
    (project?.name && project.name.includes('NHIDONG1'))
  );
  const activeContract = contracts.length > 0 ? contracts[0] : undefined;
  
  // Use state tasks instead of constant
  const projectTasks = tasks;

  if (!project) {
    return (
      <div className="flex-1 bg-gray-50 min-h-screen flex items-center justify-center flex-col">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Không tìm thấy dự án</h2>
        <Link to="/projects" className="text-orange-600 hover:underline flex items-center gap-2">
          <ArrowLeft size={16} /> Quay lại danh sách
        </Link>
      </div>
    );
  }

  const isStateBudget = project.capitalSource === 'StateBudget';
  const raciData = isStateBudget ? RACI_STATE_BUDGET : [];

  const budgetData = [
    { name: 'Khối lượng HT', value: project.budget * (project.progress / 100), fill: '#f97316' },
    { name: 'Còn lại', value: project.budget * (1 - project.progress / 100), fill: '#f1f5f9' },
  ];

  const tasksByStatus: Record<string, Task[]> = {
    [TaskStatus.OPEN]: projectTasks.filter(t => t.status === TaskStatus.OPEN),
    [TaskStatus.S0]: projectTasks.filter(t => t.status === TaskStatus.S0),
    [TaskStatus.S1]: projectTasks.filter(t => t.status === TaskStatus.S1),
    [TaskStatus.S3]: projectTasks.filter(t => t.status === TaskStatus.S3),
    [TaskStatus.S4]: projectTasks.filter(t => t.status === TaskStatus.S4),
    [TaskStatus.S6]: projectTasks.filter(t => t.status === TaskStatus.S6),
    [TaskStatus.COMPLETED]: projectTasks.filter(t => t.status === TaskStatus.COMPLETED),
  };

  return (
    <div className="flex-1 bg-gray-50 min-h-screen pb-12 overflow-x-hidden">
      <Header title="Quản trị Dự án BIM" breadcrumb={`Dự án / ${project.code} / ${project.name}`} />

      {selectedWorkflow && (
        <WorkflowModal 
          taskName={selectedWorkflow.name} 
          steps={selectedWorkflow.steps} 
          onClose={() => setSelectedWorkflow(null)} 
        />
      )}

      <main className="max-w-[1600px] mx-auto px-4 md:px-8 py-6">
        <div className="flex justify-between items-center mb-6">
          <Link to="/projects" className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-800 transition-colors font-medium">
            <ArrowLeft size={18} /> Danh mục dự án
          </Link>
          <div className="flex gap-3 items-center">
             {isSyncing && (
                 <span className="text-xs text-orange-600 flex items-center gap-1 bg-white px-2 py-1 rounded-full shadow-sm animate-pulse">
                     <Loader size={12} className="animate-spin" /> Đang đồng bộ...
                 </span>
             )}
             <span className={`flex items-center gap-2 px-4 py-1.5 rounded-xl text-xs font-bold border uppercase tracking-wider shadow-sm
                ${isStateBudget ? 'bg-purple-50 text-purple-700 border-purple-100' : 'bg-orange-50 text-orange-700 border-orange-100'}`}>
                {isStateBudget ? <Landmark size={14}/> : <Shield size={14}/>}
                {isStateBudget ? 'Vốn Ngân Sách (25.10)' : 'Vốn Ngoài Ngân Sách (25.20)'}
             </span>
          </div>
        </div>

        {/* Project Header Card */}
        <div className="bg-white rounded-2xl border border-gray-200 shadow-sm p-6 mb-8">
          {/* ... (Header content same as before) ... */}
           <div className="flex flex-col md:flex-row gap-8">
            <img 
                src={project.thumbnail} 
                alt={project.name} 
                className="w-full md:w-56 h-36 object-cover rounded-2xl shadow-md border border-gray-100"
            />
            <div className="flex-1">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h1 className="text-2xl md:text-3xl font-black text-slate-900 tracking-tight mb-2 uppercase">{project.name}</h1>
                  <div className="flex flex-wrap gap-5 text-sm text-gray-500 font-medium">
                    <span className="flex items-center gap-2"><Users size={16} className="text-orange-500"/> {project.client}</span>
                    <span className="flex items-center gap-2"><Calendar size={16} className="text-rose-500"/> Deadline: {project.deadline}</span>
                    <span className="font-mono font-bold text-slate-700">CODE: {project.code}</span>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                    <span className="px-4 py-1.5 rounded-full text-xs font-black border bg-orange-50 text-orange-700 border-orange-100 uppercase tracking-widest shadow-sm">
                      {project.status}
                    </span>
                    <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest">Tiến độ: {project.progress}%</p>
                </div>
              </div>
              <div className="mt-6">
                <div className="w-full bg-slate-100 rounded-full h-3 shadow-inner">
                  <div className="bg-gradient-to-r from-orange-500 to-orange-600 h-3 rounded-full shadow-lg transition-all duration-1000" style={{ width: `${project.progress}%` }}></div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-gray-200 mb-8 overflow-x-auto custom-scrollbar gap-2">
          {[
            { id: 'overview', label: 'Tổng quan', icon: FileText },
            { id: 'production', label: 'Quản lý Sản xuất', icon: Columns },
            { id: 'process', label: 'Tiến độ dự án (RACI)', icon: Table },
            { id: 'contracts', label: 'Hồ sơ Hợp đồng', icon: ScrollText },
            { id: 'documents', label: 'Hồ sơ Tài liệu', icon: Layers },
            { id: 'team', label: 'Đội ngũ', icon: Users }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-8 py-4 text-sm font-bold uppercase tracking-wider whitespace-nowrap transition-all border-b-4 flex items-center gap-3
                ${activeTab === tab.id 
                  ? 'border-orange-600 text-orange-600 bg-orange-50/30' 
                  : 'border-transparent text-gray-500 hover:text-slate-800 hover:bg-gray-50'}`}
            >
              <tab.icon size={18} /> {tab.label}
            </button>
          ))}
        </div>

        {/* TAB CONTENT: OVERVIEW (Same as before) */}
        {activeTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div className="lg:col-span-3 space-y-8">
                    {/* New Technical Info Section */}
                    <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
                        <SectionTitle title="Thông tin chung Dự án" icon={Info} />
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                            <InfoItem label="Nhóm dự án" value={project.projectGroup} icon={Briefcase} />
                            <InfoItem label="Loại công trình" value={project.constructionType} icon={Building2} />
                            <InfoItem label="Cấp công trình" value={project.constructionLevel} icon={Award} />
                            <InfoItem label="Quy mô / Diện tích" value={project.scale} icon={Ruler} />
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
                        <HighlightStat 
                            label="Giá trị hợp đồng" 
                            value={formatCurrency(activeContract?.totalValue || project.budget)} 
                            subValue={`Ký ngày: ${activeContract?.signedDate || 'N/A'}`}
                            icon={DollarSign} 
                            colorClass="bg-orange-50 text-orange-600" 
                        />
                        <HighlightStat 
                            label="Khối lượng hoàn thành" 
                            value={formatCurrency((activeContract?.totalValue || project.budget) * (project.progress / 100))} 
                            subValue={`Đạt ${project.progress}% kế hoạch`}
                            icon={TrendingUp} 
                            colorClass="bg-emerald-50 text-emerald-600" 
                        />
                        <HighlightStat 
                            label="Tiền về (Hóa đơn)" 
                            value={formatCurrency(activeContract?.paidValue || 0)} 
                            subValue="Chờ thanh toán đợt 1"
                            icon={CreditCard} 
                            colorClass="bg-purple-50 text-purple-600" 
                        />
                        <HighlightStat 
                            label="Thời gian còn lại" 
                            value="32 Ngày" 
                            subValue={`Dự kiến: ${project.deadline}`}
                            icon={Clock} 
                            colorClass="bg-amber-50 text-amber-600" 
                        />
                    </div>
                </div>
                <div className="space-y-8">
                    <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm">
                        <h3 className="font-black text-slate-800 mb-6 text-xs uppercase tracking-widest border-b pb-3">Phân bổ Tài chính</h3>
                        <div className="h-52 w-full relative">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie data={budgetData} innerRadius={60} outerRadius={85} paddingAngle={8} dataKey="value">
                                        {budgetData.map((entry, index) => <Cell key={`cell-${index}`} fill={entry.fill} strokeWidth={0} />)}
                                    </Pie>
                                    <Tooltip formatter={(value: number) => formatCurrency(value)} />
                                </PieChart>
                            </ResponsiveContainer>
                            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                                <span className="text-2xl font-black text-slate-800">{project.progress}%</span>
                                <span className="text-[8px] font-bold text-gray-400 uppercase">Khối lượng HT</span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* --- 4. PRODUCTION (KANBAN) WITH REALTIME --- */}
        {activeTab === 'production' && (
            <div className="space-y-6 animate-fade-in">
                <div className="flex justify-between items-center bg-white p-4 rounded-xl border border-gray-200 shadow-sm">
                    <div className="flex gap-3">
                        <button className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">
                            <Filter size={16} /> Lọc theo bộ môn
                        </button>
                        <button className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50">
                            <UserIcon size={16} /> Lọc theo nhân sự
                        </button>
                    </div>
                    <div className="flex gap-2">
                        <button 
                            onClick={() => setViewMode('list')}
                            className={`p-2 rounded-lg border ${viewMode === 'list' ? 'bg-orange-50 border-orange-200 text-orange-600' : 'border-gray-200 text-gray-500'}`}
                        >
                            <List size={20} />
                        </button>
                        <button 
                            onClick={() => setViewMode('board')}
                            className={`p-2 rounded-lg border ${viewMode === 'board' ? 'bg-orange-50 border-orange-200 text-orange-600' : 'border-gray-200 text-gray-500'}`}
                        >
                            <Columns size={20} />
                        </button>
                        <button className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg text-sm font-bold shadow-md hover:bg-orange-700 ml-2">
                            <Plus size={18} /> Tạo công việc mới
                        </button>
                    </div>
                </div>

                {viewMode === 'board' ? (
                    <div className="flex overflow-x-auto gap-4 pb-4 h-[calc(100vh-400px)] min-h-[500px] custom-scrollbar">
                        <KanbanColumn 
                            title="Chưa thực hiện" 
                            status={TaskStatus.OPEN} 
                            tasks={tasksByStatus[TaskStatus.OPEN]} 
                            count={tasksByStatus[TaskStatus.OPEN]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="S0 - Đang triển khai" 
                            status={TaskStatus.S0} 
                            tasks={tasksByStatus[TaskStatus.S0]} 
                            count={tasksByStatus[TaskStatus.S0]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="S1 - Phối hợp bộ môn" 
                            status={TaskStatus.S1} 
                            tasks={tasksByStatus[TaskStatus.S1]} 
                            count={tasksByStatus[TaskStatus.S1]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="S3 - Kiểm tra nội bộ" 
                            status={TaskStatus.S3} 
                            tasks={tasksByStatus[TaskStatus.S3]} 
                            count={tasksByStatus[TaskStatus.S3]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="S4 - Lãnh đạo duyệt" 
                            status={TaskStatus.S4} 
                            tasks={tasksByStatus[TaskStatus.S4]} 
                            count={tasksByStatus[TaskStatus.S4]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="S6 - Trình khách hàng" 
                            status={TaskStatus.S6} 
                            tasks={tasksByStatus[TaskStatus.S6]} 
                            count={tasksByStatus[TaskStatus.S6]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                        <KanbanColumn 
                            title="Hoàn thành" 
                            status={TaskStatus.COMPLETED} 
                            tasks={tasksByStatus[TaskStatus.COMPLETED]} 
                            count={tasksByStatus[TaskStatus.COMPLETED]?.length || 0} 
                            onMove={handleTaskMove}
                        />
                    </div>
                ) : (
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                        <table className="w-full text-left text-sm">
                            <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase font-bold text-gray-500">
                                <tr>
                                    <th className="px-6 py-4">Mã CV</th>
                                    <th className="px-6 py-4">Tên công việc</th>
                                    <th className="px-6 py-4">Người thực hiện</th>
                                    <th className="px-6 py-4">Trạng thái</th>
                                    <th className="px-6 py-4">Tiến độ</th>
                                    <th className="px-6 py-4">Hạn chót</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {projectTasks.map(task => (
                                    <tr key={task.id} className="hover:bg-gray-50">
                                        <td className="px-6 py-4 font-mono text-xs text-gray-500">{task.code}</td>
                                        <td className="px-6 py-4 font-medium text-gray-800">{task.name}</td>
                                        <td className="px-6 py-4 flex items-center gap-2">
                                            {task.assignee?.avatar && <img src={task.assignee.avatar} className="w-6 h-6 rounded-full" />}
                                            <span>{task.assignee?.name}</span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`text-[10px] font-bold px-2 py-1 rounded border 
                                                ${task.status === TaskStatus.S0 ? 'bg-blue-50 text-blue-700 border-blue-200' : 'bg-gray-100 border-gray-200'}`}>
                                                {task.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-2">
                                                <div className="w-20 bg-gray-200 rounded-full h-1.5">
                                                    <div className="bg-orange-600 h-1.5 rounded-full" style={{width: `${task.progress}%`}}></div>
                                                </div>
                                                <span className="text-xs text-gray-500">{task.progress}%</span>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4 text-gray-500">{task.dueDate}</td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        )}

        {/* ... (Other Tabs same as before) ... */}
        {activeTab === 'process' && (
            <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden p-8 space-y-10">
                <SectionTitle title="Ma trận Trách nhiệm Công việc (RACI)" icon={Table} />
                <div className="overflow-x-auto border border-gray-200 rounded-2xl">
                    <table className="w-full text-sm text-left border-collapse">
                        <thead className="bg-slate-800 text-white font-bold uppercase tracking-wider text-[11px]">
                            <tr>
                                <th className="px-6 py-5 min-w-[300px] border-r border-slate-700">Hạng mục / Nhiệm vụ</th>
                                {RACI_ROLES.map(role => <th key={role} className="px-2 py-5 text-center w-20 border-l border-slate-700">{role}</th>)}
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {raciData.map((phaseGroup, pIdx) => (
                                <React.Fragment key={pIdx}>
                                    <tr className="bg-slate-50 font-black text-slate-700 text-xs uppercase tracking-widest">
                                        <td className="px-6 py-3" colSpan={RACI_ROLES.length + 1}>{phaseGroup.phase}</td>
                                    </tr>
                                    {phaseGroup.tasks.map((task, tIdx) => {
                                      const hasWorkflow = !!TASK_WORKFLOWS[task.name];
                                      return (
                                        <tr key={tIdx} className="hover:bg-orange-50/30 transition-colors">
                                            <td className="px-6 py-4 border-r border-gray-100 text-slate-700 font-medium pl-10">
                                              <div 
                                                className={`flex items-center gap-2 ${hasWorkflow ? 'cursor-pointer hover:text-orange-600 group' : ''}`}
                                                onClick={() => hasWorkflow && setSelectedWorkflow({ name: task.name, steps: TASK_WORKFLOWS[task.name] })}
                                              >
                                                {task.name}
                                                {hasWorkflow && <ChevronRight size={14} className="text-gray-300 group-hover:text-orange-500" />}
                                              </div>
                                            </td>
                                            {RACI_ROLES.map(role => (
                                                <td key={role} className="px-2 py-4 border-r border-gray-50 text-center">
                                                    <RaciBadge value={task.roles && (task.roles as any)[role] ? (task.roles as any)[role] : ''} />
                                                </td>
                                            ))}
                                        </tr>
                                      );
                                    })}
                                </React.Fragment>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        )}

        {/* ... (Contracts, Documents, Team tabs kept same) ... */}
        {activeTab === 'contracts' && (
            contracts.length > 0 ? (
                <div className="grid grid-cols-1 gap-8">{contracts.map((c, idx) => <ContractCard key={idx} contract={c} />)}</div>
            ) : <div className="text-center p-8 text-gray-400">Chưa có hợp đồng</div>
        )}
        
        {activeTab === 'team' && (
            <div className="bg-white p-8 rounded-2xl border border-gray-200 shadow-sm">
                <div className="flex justify-between items-center mb-6 border-b pb-3">
                    <h3 className="font-black text-slate-800 text-xs uppercase tracking-widest">Nhân sự thực hiện</h3>
                </div>
                <div className="space-y-5">
                    {activeContract?.personnel && activeContract.personnel.length > 0 ? (
                        activeContract.personnel.map((p, i) => (
                            <div key={i} className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-slate-600 font-black text-xs shadow-sm">
                                    {p.name.split(' ').pop()?.charAt(0)}
                                </div>
                                <div className="overflow-hidden">
                                    <p className="text-xs font-black text-slate-800 truncate leading-tight mb-1">{p.name}</p>
                                    <p className="text-[10px] font-bold text-gray-400 truncate uppercase tracking-tighter">{p.role}</p>
                                </div>
                            </div>
                        ))
                    ) : (
                        <div className="text-xs text-gray-400 italic">Chưa cập nhật nhân sự</div>
                    )}
                </div>
            </div>
        )}

      </main>
    </div>
  );
};

export default ProjectDetail;
