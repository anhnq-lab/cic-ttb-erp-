
import React, { useState, useMemo } from 'react';
import Header from '../components/Header';
import { EMPLOYEES } from '../constants';
import { Employee } from '../types';
import { 
    Users, Search, Filter, LayoutGrid, List, Plus, 
    MoreHorizontal, Mail, Phone, MapPin, Briefcase, 
    Award, UserPlus, Building, Calendar, CheckCircle, Clock,
    X, CreditCard, Car, ShoppingCart, CalendarOff, Save, FileText
} from 'lucide-react';

const HRMList = () => {
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('grid');
  const [filterDept, setFilterDept] = useState('All');
  const [filterStatus, setFilterStatus] = useState('All'); // New Status Filter
  const [searchQuery, setSearchQuery] = useState('');
  
  // --- STATE FOR MODALS ---
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedEmployee, setSelectedEmployee] = useState<Employee | null>(null);
  
  // --- MOCK DATA STATE (Simulating Backend) ---
  const [employees, setEmployees] = useState<Employee[]>(EMPLOYEES);
  
  // New Employee Form State
  const [newEmp, setNewEmp] = useState<Partial<Employee>>({
      name: '', email: '', role: '', department: 'Kỹ thuật - BIM', status: 'Thử việc', joinDate: new Date().toISOString().split('T')[0]
  });

  const departments = ['All', ...Array.from(new Set(employees.map(e => e.department)))];

  const filteredEmployees = useMemo(() => {
      return employees.filter(emp => {
          // 1. Department Filter
          const matchesDept = filterDept === 'All' || emp.department === filterDept;
          
          // 2. Status Filter
          const matchesStatus = filterStatus === 'All' || emp.status === filterStatus;

          // 3. Search (Name, Email, Role, SKILLS)
          const query = searchQuery.toLowerCase();
          const matchesSearch = 
              emp.name.toLowerCase().includes(query) || 
              emp.email.toLowerCase().includes(query) ||
              emp.role.toLowerCase().includes(query) ||
              emp.skills.some(skill => skill.toLowerCase().includes(query)); // Search in Skills

          return matchesDept && matchesStatus && matchesSearch;
      });
  }, [employees, filterDept, filterStatus, searchQuery]);

  const getStatusColor = (status: string) => {
      switch(status) {
          case 'Chính thức': return 'bg-emerald-50 text-emerald-700 border-emerald-200';
          case 'Nghỉ phép': return 'bg-rose-50 text-rose-700 border-rose-200';
          case 'Thử việc': return 'bg-amber-50 text-amber-700 border-amber-200';
          default: return 'bg-gray-50 text-gray-700 border-gray-200';
      }
  };

  const handleAddEmployee = () => {
      if(!newEmp.name || !newEmp.email) return alert('Vui lòng nhập tên và email');
      
      const newEmployee: Employee = {
          id: `u${Date.now()}`,
          code: `CIC-${Math.floor(100 + Math.random() * 900)}`,
          name: newEmp.name!,
          email: newEmp.email!,
          role: newEmp.role || 'Nhân viên',
          department: newEmp.department || 'Kỹ thuật',
          phone: newEmp.phone || '09xx',
          avatar: `https://ui-avatars.com/api/?name=${encodeURIComponent(newEmp.name!)}&background=random&color=fff&size=150`,
          status: 'Thử việc',
          joinDate: newEmp.joinDate!,
          skills: ['Mới']
      };
      
      setEmployees([...employees, newEmployee]);
      setShowAddModal(false);
      setNewEmp({ name: '', email: '', role: '', department: 'Kỹ thuật - BIM', status: 'Thử việc', joinDate: new Date().toISOString().split('T')[0] });
  };

  return (
    <div className="flex-1 bg-gray-50 min-h-screen">
      <Header title="Quản trị Nguồn nhân lực" breadcrumb="Trang chủ / Nhân sự" />
      
      {/* --- ADD EMPLOYEE MODAL --- */}
      {showAddModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col animate-fade-in-up">
                  <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                      <h3 className="font-bold text-lg text-slate-800">Thêm nhân sự mới</h3>
                      <button onClick={() => setShowAddModal(false)}><X size={20} className="text-gray-400 hover:text-gray-600"/></button>
                  </div>
                  <div className="p-6 space-y-4">
                      <div>
                          <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Họ và tên</label>
                          <input type="text" className="w-full p-2 border rounded-lg text-sm" value={newEmp.name} onChange={e => setNewEmp({...newEmp, name: e.target.value})} placeholder="Nguyễn Văn A" />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Email</label>
                              <input type="email" className="w-full p-2 border rounded-lg text-sm" value={newEmp.email} onChange={e => setNewEmp({...newEmp, email: e.target.value})} placeholder="email@cic.com.vn" />
                          </div>
                          <div>
                              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Số điện thoại</label>
                              <input type="text" className="w-full p-2 border rounded-lg text-sm" value={newEmp.phone} onChange={e => setNewEmp({...newEmp, phone: e.target.value})} placeholder="09xx..." />
                          </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Phòng ban</label>
                              <select className="w-full p-2 border rounded-lg text-sm bg-white" value={newEmp.department} onChange={e => setNewEmp({...newEmp, department: e.target.value})}>
                                  {departments.filter(d => d !== 'All').map(d => <option key={d} value={d}>{d}</option>)}
                              </select>
                          </div>
                          <div>
                              <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Vị trí / Role</label>
                              <input type="text" className="w-full p-2 border rounded-lg text-sm" value={newEmp.role} onChange={e => setNewEmp({...newEmp, role: e.target.value})} placeholder="Kỹ sư..." />
                          </div>
                      </div>
                      <div>
                          <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Ngày gia nhập</label>
                          <input type="date" className="w-full p-2 border rounded-lg text-sm" value={newEmp.joinDate} onChange={e => setNewEmp({...newEmp, joinDate: e.target.value})} />
                      </div>
                  </div>
                  <div className="p-5 border-t border-gray-100 flex justify-end gap-2 bg-gray-50">
                      <button onClick={() => setShowAddModal(false)} className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 rounded-lg">Hủy bỏ</button>
                      <button onClick={handleAddEmployee} className="px-4 py-2 text-sm font-bold text-white bg-orange-600 hover:bg-orange-700 rounded-lg shadow-sm">Lưu nhân sự</button>
                  </div>
              </div>
          </div>
      )}

      {/* --- EMPLOYEE DETAIL MODAL (WITH TABS FOR REQUESTS & TIMEKEEPING) --- */}
      {selectedEmployee && (
          <EmployeeDetailModal employee={selectedEmployee} onClose={() => setSelectedEmployee(null)} />
      )}

      <main className="p-8 max-w-[1600px] mx-auto">
        
        {/* HRM Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
                    <Users size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500 mb-0.5">Tổng nhân sự</p>
                    <h3 className="text-2xl font-bold text-gray-800">{employees.length}</h3>
                </div>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                    <CheckCircle size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500 mb-0.5">Đang hoạt động</p>
                    <h3 className="text-2xl font-bold text-gray-800">{employees.filter(e => e.status === 'Chính thức').length}</h3>
                </div>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                    <UserPlus size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500 mb-0.5">Thử việc</p>
                    <h3 className="text-2xl font-bold text-gray-800">{employees.filter(e => e.status === 'Thử việc').length}</h3>
                </div>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm flex items-center gap-4">
                <div className="w-12 h-12 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
                    <Building size={24} />
                </div>
                <div>
                    <p className="text-sm text-gray-500 mb-0.5">Phòng ban</p>
                    <h3 className="text-2xl font-bold text-gray-800">{departments.length - 1}</h3>
                </div>
            </div>
        </div>

        {/* Toolbar */}
        <div className="flex flex-wrap justify-between items-center gap-4 mb-6">
            <div className="flex flex-col md:flex-row gap-3 overflow-x-auto max-w-full">
                {/* Department Filter Tabs */}
                <div className="flex items-center gap-3 bg-white p-1 rounded-lg border border-gray-200 shadow-sm">
                    {departments.map(dept => (
                        <button
                            key={dept}
                            onClick={() => setFilterDept(dept)}
                            className={`px-4 py-2 rounded-md text-sm font-medium transition-all whitespace-nowrap
                                ${filterDept === dept 
                                    ? 'bg-orange-50 text-orange-700 shadow-sm' 
                                    : 'text-gray-500 hover:bg-gray-50 hover:text-gray-800'}`}
                        >
                            {dept === 'All' ? 'Tất cả' : dept}
                        </button>
                    ))}
                </div>
            </div>

            <div className="flex items-center gap-3">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                    <input 
                        type="text" 
                        placeholder="Tìm tên, skill, email..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9 pr-4 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 w-64 shadow-sm transition-all"
                    />
                </div>

                <div className="relative">
                    <select 
                        value={filterStatus}
                        onChange={(e) => setFilterStatus(e.target.value)}
                        className="pl-3 pr-8 py-2 bg-white border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-orange-500 appearance-none shadow-sm cursor-pointer"
                    >
                        <option value="All">Trạng thái: Tất cả</option>
                        <option value="Chính thức">Chính thức</option>
                        <option value="Thử việc">Thử việc</option>
                        <option value="Nghỉ phép">Nghỉ phép</option>
                    </select>
                    <Filter className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 pointer-events-none" size={14} />
                </div>
                
                <div className="flex items-center gap-1 border border-gray-200 rounded-lg p-1 bg-white shadow-sm">
                    <button 
                        onClick={() => setViewMode('grid')}
                        className={`p-2 rounded transition-all ${viewMode === 'grid' ? 'bg-gray-100 text-orange-600' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        <LayoutGrid size={18} />
                    </button>
                     <button 
                        onClick={() => setViewMode('list')}
                        className={`p-2 rounded transition-all ${viewMode === 'list' ? 'bg-gray-100 text-orange-600' : 'text-gray-400 hover:text-gray-600'}`}
                    >
                        <List size={18} />
                    </button>
                </div>

                <button 
                    onClick={() => setShowAddModal(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white font-bold rounded-lg shadow-md hover:bg-orange-700 transition-all text-sm"
                >
                    <Plus size={18} /> Thêm nhân sự
                </button>
            </div>
        </div>

        {/* Content */}
        {filteredEmployees.length === 0 ? (
            <div className="p-12 text-center bg-white rounded-xl border border-gray-200 border-dashed">
                <p className="text-gray-500">Không tìm thấy nhân sự phù hợp.</p>
                <button 
                    onClick={() => { setSearchQuery(''); setFilterDept('All'); setFilterStatus('All'); }}
                    className="mt-2 text-orange-600 hover:underline text-sm font-medium"
                >
                    Xóa bộ lọc
                </button>
            </div>
        ) : (
            <>
                {viewMode === 'grid' ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4 gap-6">
                        {filteredEmployees.map((emp) => (
                            <div 
                                key={emp.id} 
                                onClick={() => setSelectedEmployee(emp)}
                                className="bg-white rounded-xl border border-gray-200 shadow-sm hover:shadow-lg hover:border-orange-200 transition-all cursor-pointer flex flex-row overflow-hidden h-44 group"
                            >
                                {/* LEFT: Avatar Zone (30%) */}
                                <div className="w-32 bg-slate-50 border-r border-gray-100 flex flex-col items-center justify-center p-2 shrink-0 relative">
                                    <div className="relative">
                                        <img src={emp.avatar} alt={emp.name} className="w-20 h-20 rounded-full object-cover border-4 border-white shadow-sm group-hover:scale-105 transition-transform duration-300" />
                                        <span className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-white ${emp.status === 'Chính thức' ? 'bg-emerald-500' : emp.status === 'Thử việc' ? 'bg-amber-500' : 'bg-rose-500'}`}></span>
                                    </div>
                                    <span className="mt-2 text-[10px] font-mono font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-gray-200 shadow-sm">
                                        {emp.code}
                                    </span>
                                </div>

                                {/* RIGHT: Info Zone (70%) */}
                                <div className="flex-1 p-4 flex flex-col justify-between overflow-hidden">
                                    <div>
                                        <h3 className="font-bold text-slate-900 text-base leading-tight truncate pr-2 group-hover:text-orange-600 transition-colors">
                                            {emp.name}
                                        </h3>
                                        <p className="text-[10px] font-bold text-orange-600 uppercase tracking-wide truncate mb-3">
                                            {emp.role}
                                        </p>
                                        
                                        <div className="space-y-1.5">
                                            <p className="text-xs text-slate-500 flex items-center gap-2 truncate" title={emp.email}>
                                                <Mail size={12} className="shrink-0 text-slate-400"/> {emp.email}
                                            </p>
                                            <p className="text-xs text-slate-500 flex items-center gap-2 truncate">
                                                <Phone size={12} className="shrink-0 text-slate-400"/> {emp.phone}
                                            </p>
                                        </div>
                                    </div>
                                    
                                    {/* Skills Tag Cloud */}
                                    <div className="flex flex-wrap gap-1 mt-2 pt-2 border-t border-gray-50">
                                        {emp.skills.slice(0, 2).map((skill, idx) => (
                                            <span key={idx} className="text-[9px] px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded border border-gray-200 truncate max-w-[80px]">
                                                {skill}
                                            </span>
                                        ))}
                                        {emp.skills.length > 2 && (
                                            <span className="text-[9px] text-gray-400 px-1 pt-0.5">+{emp.skills.length - 2}</span>
                                        )}
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : (
                    <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
                        <table className="w-full text-left">
                            <thead className="bg-gray-50 border-b border-gray-200 text-xs uppercase font-bold text-gray-500">
                                <tr>
                                    <th className="px-6 py-4">Nhân sự</th>
                                    <th className="px-6 py-4">Vị trí & Phòng ban</th>
                                    <th className="px-6 py-4">Liên hệ</th>
                                    <th className="px-6 py-4">Ngày gia nhập</th>
                                    <th className="px-6 py-4">Trạng thái</th>
                                    <th className="px-6 py-4 text-right">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100 text-sm">
                                {filteredEmployees.map((emp) => (
                                    <tr key={emp.id} className="hover:bg-gray-50 group transition-colors cursor-pointer" onClick={() => setSelectedEmployee(emp)}>
                                        <td className="px-6 py-4">
                                            <div className="flex items-center gap-3">
                                                <img src={emp.avatar} alt="" className="w-10 h-10 rounded-full object-cover border border-gray-200" />
                                                <div>
                                                    <p className="font-bold text-gray-800">{emp.name}</p>
                                                    <p className="text-xs text-gray-500 font-mono">{emp.code}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <p className="font-medium text-gray-800">{emp.role}</p>
                                            <p className="text-xs text-gray-500">{emp.department}</p>
                                        </td>
                                        <td className="px-6 py-4 text-gray-600 space-y-0.5">
                                            <div className="flex items-center gap-2 text-xs"><Mail size={12}/> {emp.email}</div>
                                            <div className="flex items-center gap-2 text-xs"><Phone size={12}/> {emp.phone}</div>
                                        </td>
                                        <td className="px-6 py-4 text-gray-600">
                                            <div className="flex items-center gap-2">
                                                <Calendar size={14} className="text-gray-400" />
                                                {emp.joinDate}
                                            </div>
                                        </td>
                                        <td className="px-6 py-4">
                                            <span className={`px-2.5 py-1 rounded text-[10px] font-bold uppercase border ${getStatusColor(emp.status)}`}>
                                                {emp.status}
                                            </span>
                                        </td>
                                        <td className="px-6 py-4 text-right">
                                            <button className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-full transition-colors">
                                                <MoreHorizontal size={18} />
                                            </button>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </>
        )}
      </main>
    </div>
  );
};

// --- SUB-COMPONENTS FOR DETAIL MODAL ---

const EmployeeDetailModal = ({ employee, onClose }: { employee: Employee, onClose: () => void }) => {
    const [activeTab, setActiveTab] = useState('info');
    
    return (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-4xl h-[85vh] overflow-hidden flex flex-col animate-fade-in-up">
                {/* Header (Increased Height for Depth) */}
                <div className="h-40 bg-gradient-to-r from-slate-800 to-slate-900 relative shrink-0">
                    <button onClick={onClose} className="absolute top-4 right-4 bg-black/20 text-white p-2 rounded-full hover:bg-black/40 backdrop-blur-md z-10"><X size={20}/></button>
                    
                    {/* Floating Avatar (Overlapping) */}
                    <div className="absolute -bottom-10 left-8 z-20">
                        <img src={employee.avatar} className="w-32 h-32 rounded-full border-4 border-white shadow-xl bg-white object-cover" />
                        <span className={`absolute bottom-2 right-2 w-6 h-6 rounded-full border-4 border-white ${employee.status === 'Chính thức' ? 'bg-emerald-500' : 'bg-amber-500'}`}></span>
                    </div>
                </div>

                {/* Info Section (Under Header, beside Avatar) */}
                <div className="pt-2 px-8 pb-0">
                    <div className="pl-36 mb-6">
                        <h2 className="text-2xl font-bold text-slate-900">{employee.name}</h2>
                        <div className="flex items-center gap-3 text-sm mt-1">
                            <span className="font-bold text-orange-600 uppercase tracking-wide">{employee.role}</span>
                            <span className="text-gray-300">|</span>
                            <span className="text-gray-500 font-medium">{employee.department}</span>
                        </div>
                    </div>
                    
                    <div className="border-b border-gray-200">
                        <div className="flex gap-8">
                            <button onClick={() => setActiveTab('info')} className={`pb-3 text-sm font-bold border-b-2 transition-colors ${activeTab === 'info' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Thông tin cá nhân</button>
                            <button onClick={() => setActiveTab('timekeeping')} className={`pb-3 text-sm font-bold border-b-2 transition-colors ${activeTab === 'timekeeping' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Chấm công (Timesheet)</button>
                            <button onClick={() => setActiveTab('requests')} className={`pb-3 text-sm font-bold border-b-2 transition-colors ${activeTab === 'requests' ? 'border-orange-600 text-orange-600' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>Đề xuất & Dịch vụ</button>
                        </div>
                    </div>
                </div>

                <div className="flex-1 overflow-y-auto p-8 bg-gray-50/50">
                    {activeTab === 'info' && <EmployeeInfoTab employee={employee} />}
                    {activeTab === 'timekeeping' && <TimekeepingTab />}
                    {activeTab === 'requests' && <RequestTab />}
                </div>
            </div>
        </div>
    );
};

const EmployeeInfoTab = ({ employee }: { employee: Employee }) => (
    <div className="grid grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm space-y-4">
            <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-2">Thông tin liên hệ</h4>
            <div className="space-y-3">
                <div className="flex justify-between border-b border-gray-50 pb-2">
                    <span className="text-sm text-gray-500">Email</span>
                    <span className="text-sm font-medium text-gray-800">{employee.email}</span>
                </div>
                <div className="flex justify-between border-b border-gray-50 pb-2">
                    <span className="text-sm text-gray-500">Điện thoại</span>
                    <span className="text-sm font-medium text-gray-800">{employee.phone}</span>
                </div>
                <div className="flex justify-between border-b border-gray-50 pb-2">
                    <span className="text-sm text-gray-500">Mã nhân viên</span>
                    <span className="text-sm font-mono text-gray-800 bg-gray-100 px-2 rounded">{employee.code}</span>
                </div>
                <div className="flex justify-between border-b border-gray-50 pb-2">
                    <span className="text-sm text-gray-500">Ngày vào làm</span>
                    <span className="text-sm font-medium text-gray-800">{employee.joinDate}</span>
                </div>
            </div>
        </div>
        <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm">
            <h4 className="font-bold text-gray-800 text-sm uppercase tracking-wider mb-4">Kỹ năng & Chuyên môn</h4>
            <div className="flex flex-wrap gap-2">
                {employee.skills.map(skill => (
                    <span key={skill} className="bg-slate-100 text-slate-700 px-3 py-1.5 rounded-lg text-sm font-medium border border-slate-200">
                        {skill}
                    </span>
                ))}
            </div>
        </div>
    </div>
);

const TimekeepingTab = () => (
    <div className="space-y-6">
        <div className="grid grid-cols-4 gap-4">
            <div className="bg-white p-4 rounded-xl border border-gray-200 text-center">
                <p className="text-xs text-gray-500 uppercase">Công chuẩn</p>
                <p className="text-2xl font-bold text-gray-800">22</p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-200 text-center">
                <p className="text-xs text-gray-500 uppercase">Công thực tế</p>
                <p className="text-2xl font-bold text-emerald-600">20.5</p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-200 text-center">
                <p className="text-xs text-gray-500 uppercase">Đi muộn / Về sớm</p>
                <p className="text-2xl font-bold text-orange-600">2</p>
            </div>
            <div className="bg-white p-4 rounded-xl border border-gray-200 text-center">
                <p className="text-xs text-gray-500 uppercase">Nghỉ phép</p>
                <p className="text-2xl font-bold text-blue-600">1</p>
            </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-gray-50 border-b border-gray-200 font-bold text-sm text-gray-700">Lịch sử chấm công (Tháng 03/2025)</div>
            <table className="w-full text-left text-sm">
                <thead className="bg-white text-gray-500 border-b border-gray-100">
                    <tr>
                        <th className="px-6 py-3 font-normal">Ngày</th>
                        <th className="px-6 py-3 font-normal">Check In</th>
                        <th className="px-6 py-3 font-normal">Check Out</th>
                        <th className="px-6 py-3 font-normal">Công</th>
                        <th className="px-6 py-3 font-normal text-right">Ghi chú</th>
                    </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                    {[...Array(5)].map((_, i) => (
                        <tr key={i}>
                            <td className="px-6 py-3 font-medium text-gray-800">2{5-i}/03/2025</td>
                            <td className="px-6 py-3 text-emerald-600">08:0{i} AM</td>
                            <td className="px-6 py-3 text-emerald-600">17:3{i} PM</td>
                            <td className="px-6 py-3 font-bold">1.0</td>
                            <td className="px-6 py-3 text-right text-gray-400">-</td>
                        </tr>
                    ))}
                    <tr>
                        <td className="px-6 py-3 font-medium text-gray-800">20/03/2025</td>
                        <td className="px-6 py-3 text-orange-500">08:45 AM</td>
                        <td className="px-6 py-3 text-emerald-600">17:30 PM</td>
                        <td className="px-6 py-3 font-bold">1.0</td>
                        <td className="px-6 py-3 text-right text-orange-500 text-xs font-bold">ĐI MUỘN</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
);

const RequestTab = () => {
    const [requestType, setRequestType] = useState('leave'); // leave, purchase, vehicle

    return (
        <div className="flex gap-6 h-full">
            {/* Sidebar Menu for Requests */}
            <div className="w-48 flex-shrink-0 space-y-2">
                <button 
                    onClick={() => setRequestType('leave')} 
                    className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors ${requestType === 'leave' ? 'bg-orange-50 text-orange-700' : 'text-gray-600 hover:bg-gray-100'}`}
                >
                    <CalendarOff size={18}/> Xin nghỉ phép
                </button>
                <button 
                    onClick={() => setRequestType('purchase')} 
                    className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors ${requestType === 'purchase' ? 'bg-orange-50 text-orange-700' : 'text-gray-600 hover:bg-gray-100'}`}
                >
                    <ShoppingCart size={18}/> Đề xuất mua sắm
                </button>
                <button 
                    onClick={() => setRequestType('vehicle')} 
                    className={`w-full text-left px-4 py-3 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors ${requestType === 'vehicle' ? 'bg-orange-50 text-orange-700' : 'text-gray-600 hover:bg-gray-100'}`}
                >
                    <Car size={18}/> Đặt xe công tác
                </button>
            </div>

            {/* Form Content */}
            <div className="flex-1 bg-white p-6 rounded-xl border border-gray-200 shadow-sm h-fit">
                {requestType === 'leave' && (
                    <div className="space-y-4 animate-fade-in-up">
                        <div className="flex items-center gap-3 mb-4 border-b border-gray-100 pb-3">
                            <div className="p-2 bg-orange-100 text-orange-600 rounded-lg"><CalendarOff size={20}/></div>
                            <h3 className="font-bold text-gray-800">Tạo đơn xin nghỉ phép</h3>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Loại nghỉ</label>
                                <select className="w-full p-2 border rounded-lg text-sm bg-white"><option>Nghỉ phép năm</option><option>Nghỉ ốm</option><option>Nghỉ không lương</option></select>
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Số ngày</label>
                                <input type="number" className="w-full p-2 border rounded-lg text-sm" placeholder="1" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Từ ngày</label>
                                <input type="date" className="w-full p-2 border rounded-lg text-sm" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Đến ngày</label>
                                <input type="date" className="w-full p-2 border rounded-lg text-sm" />
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Lý do</label>
                            <textarea className="w-full p-2 border rounded-lg text-sm h-24" placeholder="Nhập lý do nghỉ..."></textarea>
                        </div>
                        <div className="pt-2 flex justify-end">
                            <button className="px-6 py-2 bg-orange-600 text-white font-bold rounded-lg hover:bg-orange-700 shadow-md flex items-center gap-2">
                                <Save size={16}/> Gửi đơn
                            </button>
                        </div>
                    </div>
                )}

                {requestType === 'purchase' && (
                    <div className="space-y-4 animate-fade-in-up">
                        <div className="flex items-center gap-3 mb-4 border-b border-gray-100 pb-3">
                            <div className="p-2 bg-blue-100 text-blue-600 rounded-lg"><ShoppingCart size={20}/></div>
                            <h3 className="font-bold text-gray-800">Đề xuất mua sắm thiết bị</h3>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Tên thiết bị / Vật tư</label>
                            <input type="text" className="w-full p-2 border rounded-lg text-sm" placeholder="VD: Màn hình Dell UltraSharp..." />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Số lượng</label>
                                <input type="number" className="w-full p-2 border rounded-lg text-sm" placeholder="1" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Đơn giá dự kiến (VNĐ)</label>
                                <input type="text" className="w-full p-2 border rounded-lg text-sm" placeholder="5.000.000" />
                            </div>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Mục đích sử dụng</label>
                            <textarea className="w-full p-2 border rounded-lg text-sm h-24" placeholder="Giải trình mục đích..."></textarea>
                        </div>
                        <div className="pt-2 flex justify-end">
                            <button className="px-6 py-2 bg-blue-600 text-white font-bold rounded-lg hover:bg-blue-700 shadow-md flex items-center gap-2">
                                <Save size={16}/> Gửi đề xuất
                            </button>
                        </div>
                    </div>
                )}

                {requestType === 'vehicle' && (
                    <div className="space-y-4 animate-fade-in-up">
                        <div className="flex items-center gap-3 mb-4 border-b border-gray-100 pb-3">
                            <div className="p-2 bg-emerald-100 text-emerald-600 rounded-lg"><Car size={20}/></div>
                            <h3 className="font-bold text-gray-800">Đăng ký sử dụng xe công ty</h3>
                        </div>
                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Điểm đến</label>
                            <input type="text" className="w-full p-2 border rounded-lg text-sm" placeholder="VD: Công trường VinHomes Ocean Park..." />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Ngày đi</label>
                                <input type="date" className="w-full p-2 border rounded-lg text-sm" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Giờ xuất phát</label>
                                <input type="time" className="w-full p-2 border rounded-lg text-sm" />
                            </div>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Số người</label>
                                <input type="number" className="w-full p-2 border rounded-lg text-sm" placeholder="4" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Loại xe đề xuất</label>
                                <select className="w-full p-2 border rounded-lg text-sm bg-white"><option>Xe 4 chỗ</option><option>Xe 7 chỗ</option></select>
                            </div>
                        </div>
                        <div className="pt-2 flex justify-end">
                            <button className="px-6 py-2 bg-emerald-600 text-white font-bold rounded-lg hover:bg-emerald-700 shadow-md flex items-center gap-2">
                                <Save size={16}/> Đặt xe
                            </button>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default HRMList;
