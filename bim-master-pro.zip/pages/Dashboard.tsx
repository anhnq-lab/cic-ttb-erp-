
import React from 'react';
import Header from '../components/Header';
import { KPIS, REVENUE_DATA, RESOURCE_DATA, PROJECTS } from '../constants';
import { KpiMetric, ProjectStatus } from '../types';
import { DollarSign, TrendingUp, Activity, Users, AlertCircle, Clock } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';

const StatCard: React.FC<{ kpi: KpiMetric }> = ({ kpi }) => {
  const Icon = kpi.icon === 'dollar' ? DollarSign : 
               kpi.icon === 'trending-up' ? TrendingUp :
               kpi.icon === 'activity' ? Activity : Users;

  return (
    <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-sm font-medium text-gray-500 mb-1">{kpi.label}</p>
          <h3 className="text-2xl font-bold text-gray-800">{kpi.value}</h3>
        </div>
        <div className={`p-2 rounded-lg ${kpi.isPositive ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}>
          <Icon size={20} />
        </div>
      </div>
      <div className="flex items-center gap-2">
        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${kpi.isPositive ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
          {kpi.isPositive ? '+' : ''}{kpi.trend}%
        </span>
        <span className="text-xs text-gray-400">so với tháng trước</span>
      </div>
    </div>
  );
};

const Dashboard = () => {
  return (
    <div className="flex-1 bg-gray-50 min-h-screen">
      <Header title="Tổng quan điều hành" breadcrumb="Trang chủ / Tổng quan" />
      
      <main className="p-8 max-w-[1600px] mx-auto">
        {/* Date Filter & Export Row */}
        <div className="flex justify-between items-center mb-8">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <Clock size={16} />
            <span>Cập nhật lần cuối: Hôm nay, 09:41 AM</span>
          </div>
          <div className="flex gap-3">
             <select className="bg-white border border-gray-200 text-gray-700 text-sm rounded-lg px-3 py-2 outline-none focus:border-orange-500">
                <option>Quý 4 - 2023</option>
                <option>Quý 3 - 2023</option>
             </select>
             <button className="text-orange-600 bg-orange-50 hover:bg-orange-100 font-medium rounded-lg text-sm px-4 py-2 transition-colors">
                Xuất Báo cáo
             </button>
          </div>
        </div>

        {/* KPI Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {KPIS.map((kpi, index) => (
            <StatCard key={index} kpi={kpi} />
          ))}
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Revenue Chart */}
          <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
            <div className="flex justify-between items-center mb-6">
              <h3 className="font-bold text-gray-800">Hiệu quả Tài chính (YTD)</h3>
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-orange-500"></span>
                  <span className="text-gray-500">Doanh thu</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="w-3 h-3 rounded-full bg-rose-400"></span>
                  <span className="text-gray-500">Chi phí</span>
                </div>
              </div>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={REVENUE_DATA} margin={{ top: 10, right: 30, left: 0, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorRv" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#f97316" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#f97316" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} dy={10} />
                  <YAxis axisLine={false} tickLine={false} tick={{fill: '#9ca3af', fontSize: 12}} />
                  <CartesianGrid vertical={false} stroke="#f3f4f6" />
                  <Tooltip 
                    contentStyle={{borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)'}}
                  />
                  <Area type="monotone" dataKey="revenue" stroke="#f97316" strokeWidth={3} fillOpacity={1} fill="url(#colorRv)" />
                  <Area type="monotone" dataKey="expenses" stroke="#fb7185" strokeWidth={3} fill="none" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Resource Utilization */}
          <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col">
            <h3 className="font-bold text-gray-800 mb-2">Tỷ lệ Nguồn lực</h3>
            <p className="text-sm text-gray-500 mb-6">Giờ tính phí vs. Giờ nội bộ</p>
            
            <div className="flex-1 flex items-center justify-center relative">
              <ResponsiveContainer width="100%" height={240}>
                <PieChart>
                  <Pie
                    data={RESOURCE_DATA}
                    innerRadius={65}
                    outerRadius={85}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {RESOURCE_DATA.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index === 0 ? '#f97316' : '#e2e8f0'} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-3xl font-bold text-gray-800">75%</span>
                <span className="text-xs text-gray-500 font-medium">Tính phí</span>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-4 mt-6">
                <div className="bg-orange-50 p-3 rounded-lg text-center">
                    <span className="block text-xs text-orange-600 mb-1">Tính phí</span>
                    <span className="block font-bold text-gray-800">2,450h</span>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg text-center">
                    <span className="block text-xs text-gray-500 mb-1">Nội bộ</span>
                    <span className="block font-bold text-gray-800">815h</span>
                </div>
            </div>
          </div>
        </div>

        {/* Project Status & Action Items */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <div className="flex justify-between items-center mb-6">
                    <h3 className="font-bold text-gray-800">Trạng thái Dự án Hoạt động</h3>
                    <button className="text-sm text-orange-600 hover:text-orange-700 font-medium">Xem tất cả</button>
                </div>
                <div className="overflow-x-auto">
                    <table className="w-full text-sm text-left">
                        <thead className="text-xs text-gray-400 uppercase bg-gray-50/50">
                            <tr>
                                <th className="px-4 py-3 font-semibold">Tên dự án</th>
                                <th className="px-4 py-3 font-semibold">Trạng thái</th>
                                <th className="px-4 py-3 font-semibold">Ngân sách (Đã dùng)</th>
                                <th className="px-4 py-3 font-semibold">Tiến độ</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {PROJECTS.map(proj => (
                                <tr key={proj.id} className="hover:bg-gray-50/50 transition-colors">
                                    <td className="px-4 py-4">
                                        <p className="font-medium text-gray-800">{proj.name}</p>
                                        <p className="text-xs text-gray-500">{proj.client} • {proj.budget / 1000000000}B</p>
                                    </td>
                                    <td className="px-4 py-4">
                                        <span className={`px-2.5 py-1 rounded-full text-xs font-medium 
                                            ${proj.status === ProjectStatus.IN_PROGRESS ? 'bg-orange-50 text-orange-600' : 
                                              proj.status === ProjectStatus.PLANNING ? 'bg-gray-100 text-gray-600' :
                                              proj.status === ProjectStatus.DELAYED ? 'bg-rose-50 text-rose-600' : 'bg-emerald-50 text-emerald-600'
                                            }`}>
                                            {proj.status}
                                        </span>
                                    </td>
                                    <td className="px-4 py-4">
                                        <div className="text-gray-700 font-medium">
                                            ${(proj.spent / 1000000).toFixed(1)}M <span className="text-gray-400">/ ${(proj.budget / 1000000).toFixed(1)}M</span>
                                        </div>
                                    </td>
                                    <td className="px-4 py-4 w-48">
                                        <div className="flex items-center gap-3">
                                            <span className="font-medium text-gray-700">{proj.progress}%</span>
                                            <div className="flex-1 h-2 bg-gray-100 rounded-full overflow-hidden">
                                                <div 
                                                    className={`h-full rounded-full ${proj.progress > 80 ? 'bg-emerald-500' : 'bg-orange-500'}`} 
                                                    style={{width: `${proj.progress}%`}}
                                                ></div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <div className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm">
                <h3 className="font-bold text-gray-800 mb-1">Cảnh báo Cần xử lý</h3>
                <p className="text-sm text-gray-500 mb-6">3 cảnh báo quan trọng cần xử lý</p>
                
                <div className="space-y-4">
                    <div className="p-4 bg-rose-50 border border-rose-100 rounded-lg">
                        <div className="flex gap-3">
                            <AlertCircle className="text-rose-600 shrink-0" size={20} />
                            <div>
                                <h4 className="text-sm font-bold text-gray-800 mb-1">Vượt ngân sách</h4>
                                <p className="text-xs text-gray-600 leading-relaxed mb-2">
                                    Dự án Metro Station V đã vượt ngân sách vật tư Q4 15%.
                                </p>
                                <button className="text-xs font-semibold text-rose-600 hover:text-rose-700">Xem chi tiết</button>
                            </div>
                        </div>
                    </div>

                    <div className="p-4 bg-amber-50 border border-amber-100 rounded-lg">
                        <div className="flex gap-3">
                            <AlertCircle className="text-amber-600 shrink-0" size={20} />
                            <div>
                                <h4 className="text-sm font-bold text-gray-800 mb-1">Hợp đồng đang chờ</h4>
                                <p className="text-xs text-gray-600 leading-relaxed mb-2">
                                    Thỏa thuận nhà thầu Skyline Residential giai đoạn 2 đang chờ xử lý.
                                </p>
                                <button className="text-xs font-semibold text-amber-600 hover:text-amber-700">Xem hợp đồng</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
