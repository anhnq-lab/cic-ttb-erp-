
import React, { useState, useMemo, useRef, useEffect } from 'react';
import Header from '../components/Header';
import { PROJECTS, PROJECT_TEMPLATES, MOCK_USERS, TASKS, PROJECT_GROUPS, CONSTRUCTION_LEVELS, CONSTRUCTION_TYPES } from '../constants';
import { MoreHorizontal, Calendar, Users, Filter, LayoutGrid, List, MapPin, Clock, Plus, X, ChevronRight, Check, Sparkles, User, Search as SearchIcon, Building2, Download, Upload, FileSpreadsheet, Link as LinkIcon, RefreshCw, Save, AlertTriangle, Code, Copy } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Project, ProjectStatus, TaskStatus, TaskPriority } from '../types';
import { fetchProjectsFromGoogleSheet, saveProjectToGoogleSheet } from '../utils/googleSheets';

const ProjectList = () => {
  const navigate = useNavigate();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [viewMode, setViewMode] = useState<'list' | 'grid'>('grid');
  
  // Local state to simulate adding projects (in a real app, this is API/Global State)
  const [localProjects, setLocalProjects] = useState<Project[]>(PROJECTS);

  // --- FILTER STATES ---
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('All');
  const [capitalFilter, setCapitalFilter] = useState<string>('All');
  
  // --- GOOGLE SHEETS STATE ---
  const [showSheetModal, setShowSheetModal] = useState(false);
  const [showScriptCode, setShowScriptCode] = useState(false); // Toggle view script
  const [sheetId, setSheetId] = useState('');
  const [sheetGid, setSheetGid] = useState('0');
  const [scriptUrl, setScriptUrl] = useState(''); // New State for Write API
  const [isSyncing, setIsSyncing] = useState(false);

  // Load saved config on mount
  useEffect(() => {
      const savedSheetId = localStorage.getItem('sheetId');
      const savedScriptUrl = localStorage.getItem('scriptUrl');
      if (savedSheetId) setSheetId(savedSheetId);
      if (savedScriptUrl) setScriptUrl(savedScriptUrl);
  }, []);

  // --- CREATE PROJECT MODAL STATE ---
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [step, setStep] = useState(1);
  const [newProjectData, setNewProjectData] = useState<Partial<Project>>({
      name: '',
      code: '',
      client: '',
      location: '',
      manager: '',
      budget: 0,
      capitalSource: 'StateBudget',
      projectGroup: PROJECT_GROUPS[2], // Default Nhóm B
      constructionType: CONSTRUCTION_TYPES[0], // Default Dân dụng
      constructionLevel: CONSTRUCTION_LEVELS[2], // Default Cấp II
      scale: ''
  });
  const [startDate, setStartDate] = useState(new Date().toISOString().split('T')[0]);
  
  // Role Mapping: Key = Abstract Role (e.g. 'QL BIM'), Value = User ID
  const [roleMapping, setRoleMapping] = useState<Record<string, string>>({
      'GĐTT': 'u1', // Default
      'PGĐTT': 'u2',
      'QLDA': '',
      'QL BIM': '',
      'TNDH': '',
      'Admin': 'u7'
  });

  // --- SMART FILTERING LOGIC ---
  const filteredProjects = useMemo(() => {
      return localProjects.filter(project => {
          // 1. Keyword Search (Name, Code, Client)
          const query = searchQuery.toLowerCase();
          const matchesSearch = 
              project.name.toLowerCase().includes(query) ||
              project.code.toLowerCase().includes(query) ||
              project.client.toLowerCase().includes(query);

          // 2. Status Filter
          const matchesStatus = statusFilter === 'All' || project.status === statusFilter;

          // 3. Capital Source Filter
          const matchesCapital = capitalFilter === 'All' || project.capitalSource === capitalFilter;

          return matchesSearch && matchesStatus && matchesCapital;
      });
  }, [localProjects, searchQuery, statusFilter, capitalFilter]);

  // --- EXPORT FUNCTION ---
  const handleExport = () => {
      // Define headers
      const headers = ['Mã DA', 'Tên Dự Án', 'Khách Hàng', 'Địa Điểm', 'Quản Lý (PM)', 'Trạng Thái', 'Tiến Độ (%)', 'Ngân Sách', 'Nguồn Vốn'];
      
      // Convert data to CSV format
      const csvContent = [
          headers.join(','),
          ...filteredProjects.map(p => {
              // Wrap strings in quotes to handle commas within fields
              return [
                  `"${p.code}"`,
                  `"${p.name}"`,
                  `"${p.client}"`,
                  `"${p.location || ''}"`,
                  `"${p.manager || ''}"`,
                  `"${p.status}"`,
                  p.progress,
                  p.budget,
                  `"${p.capitalSource}"`
              ].join(',');
          })
      ].join('\n');

      // Create blob and download link
      const blob = new Blob([`\uFEFF${csvContent}`], { type: 'text/csv;charset=utf-8;' }); // Add BOM for Excel UTF-8
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', `Danh_sach_du_an_${new Date().toISOString().split('T')[0]}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
  };

  // --- IMPORT FUNCTION ---
  const handleImportClick = () => {
      fileInputRef.current?.click();
  };

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      const file = event.target.files?.[0];
      if (!file) return;

      const reader = new FileReader();
      reader.onload = (e) => {
          try {
              const text = e.target?.result as string;
              const rows = text.split('\n');
              
              // Skip header row and filter empty rows
              const newProjects: Project[] = rows.slice(1).filter(r => r.trim()).map((row, index) => {
                  const cols = row.split(',').map(c => c.replace(/^"|"$/g, '').trim());
                  
                  return {
                      id: `IMP-${Date.now()}-${index}`,
                      code: cols[0] || `IMP-${index}`,
                      name: cols[1] || 'Imported Project',
                      client: cols[2] || 'Unknown Client',
                      location: cols[3] || '',
                      manager: cols[4] || '',
                      status: (cols[5] as any) || ProjectStatus.PLANNING,
                      progress: parseInt(cols[6]) || 0,
                      budget: parseInt(cols[7]) || 0,
                      capitalSource: (cols[8] === 'StateBudget' ? 'StateBudget' : 'NonStateBudget'),
                      spent: 0,
                      deadline: new Date(new Date().setMonth(new Date().getMonth() + 6)).toISOString().split('T')[0],
                      members: 1,
                      thumbnail: `https://picsum.photos/seed/${index}/400/300`
                  };
              });

              if (newProjects.length > 0) {
                  setLocalProjects(prev => [...newProjects, ...prev]);
                  alert(`Đã nhập thành công ${newProjects.length} dự án!`);
              } else {
                  alert('Không tìm thấy dữ liệu hợp lệ trong file.');
              }
          } catch (error) {
              alert('Lỗi khi đọc file. Vui lòng kiểm tra định dạng CSV.');
              console.error(error);
          }
          if (fileInputRef.current) fileInputRef.current.value = '';
      };
      reader.readAsText(file);
  };

  // --- GOOGLE SHEETS SYNC ---
  const handleSyncSheet = async () => {
      if(!sheetId) return alert('Vui lòng nhập ID Google Sheet');
      
      const cleanScriptUrl = scriptUrl.trim(); // Trim whitespace

      setIsSyncing(true);
      try {
          // Save config
          localStorage.setItem('sheetId', sheetId);
          localStorage.setItem('scriptUrl', cleanScriptUrl);

          const sheetProjects = await fetchProjectsFromGoogleSheet(sheetId, sheetGid);
          if(sheetProjects.length > 0) {
              setLocalProjects(sheetProjects);
              setShowSheetModal(false);
              alert(`Kết nối thành công! Đã tải ${sheetProjects.length} dự án từ Sheet.`);
          } else {
              alert('Kết nối thành công nhưng Sheet trống hoặc không đúng định dạng cột.');
          }
      } catch (error: any) {
          console.error(error);
          if (error.message.includes('Publish to web')) {
              alert(`LỖI QUYỀN TRUY CẬP:\nSheet chưa được công khai.\n\nVui lòng vào Sheet > File > Share > Publish to web > Chọn CSV > Publish.`);
          } else {
              alert('Lỗi kết nối: Vui lòng kiểm tra kỹ Sheet ID.');
          }
      } finally {
          setIsSyncing(false);
      }
  };

  const STANDARD_SCRIPT = `function doPost(e) {
  var lock = LockService.getScriptLock();
  lock.tryLock(10000);

  try {
    var doc = SpreadsheetApp.getActiveSpreadsheet();
    // Lấy Sheet đầu tiên (thay vì tìm theo tên 'Sheet1' dễ lỗi)
    var sheet = doc.getSheets()[0]; 
    
    var data = JSON.parse(e.postData.contents);
    var nextRow = sheet.getLastRow() + 1;

    // Ghi dữ liệu vào hàng tiếp theo
    sheet.getRange(nextRow, 1, 1, data.length).setValues([data]);

    return ContentService
      .createTextOutput(JSON.stringify({ 'result': 'success', 'row': nextRow }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  catch (e) {
    return ContentService
      .createTextOutput(JSON.stringify({ 'result': 'error', 'error': e }))
      .setMimeType(ContentService.MimeType.JSON);
  }
  finally {
    lock.releaseLock();
  }
}`;

  // Calculate Tasks based on Template
  const calculateAutoTasks = () => {
      const template = PROJECT_TEMPLATES[newProjectData.capitalSource || 'StateBudget'];
      if (!template) return [];
      
      const start = new Date(startDate);
      
      return template.map((t, idx) => {
          // Calc dates
          const taskStart = new Date(start);
          taskStart.setDate(start.getDate() + t.offset);
          
          const taskEnd = new Date(taskStart);
          taskEnd.setDate(taskStart.getDate() + t.duration);
          
          // Find assignee based on role mapping
          const mappedUserId = roleMapping[t.assigneeRole];
          const assignedUser = MOCK_USERS.find(u => u.id === mappedUserId) || MOCK_USERS[0];

          return {
              id: `NEW-T-${idx}`,
              code: t.code,
              name: t.name,
              projectId: `NEW-${newProjectData.code}`,
              assignee: { 
                  name: assignedUser.name, 
                  avatar: assignedUser.avatar, 
                  role: t.assigneeRole 
              },
              status: TaskStatus.OPEN,
              priority: t.priority,
              startDate: taskStart.toISOString().split('T')[0],
              dueDate: taskEnd.toISOString().split('T')[0],
              progress: 0,
              tags: ['Tự động tạo']
          };
      });
  };

  const handleCreateProject = async () => {
      setIsSaving(true);
      // 1. Create Project Object
      const newProject: Project = {
          id: `NEW-${newProjectData.code || Date.now()}`,
          code: newProjectData.code || '',
          name: newProjectData.name || '',
          client: newProjectData.client || '',
          location: newProjectData.location || '',
          manager: newProjectData.manager || '',
          capitalSource: newProjectData.capitalSource as 'StateBudget' | 'NonStateBudget',
          status: ProjectStatus.PLANNING, // Default to Planning/Potential
          progress: 0,
          budget: newProjectData.budget || 0,
          spent: 0,
          deadline: new Date(new Date(startDate).setMonth(new Date(startDate).getMonth() + 6)).toISOString().split('T')[0], // Mock deadline 6 months later
          members: Object.values(roleMapping).filter(Boolean).length,
          thumbnail: 'https://picsum.photos/seed/new/400/300',
          projectGroup: newProjectData.projectGroup,
          constructionType: newProjectData.constructionType,
          constructionLevel: newProjectData.constructionLevel,
          scale: newProjectData.scale
      };

      // 2. Generate Tasks (Simulation)
      const generatedTasks = calculateAutoTasks();
      
      // 3. Save to Google Sheets if Script URL is present
      if (scriptUrl) {
          try {
              const cleanScriptUrl = scriptUrl.trim();
              const success = await saveProjectToGoogleSheet(newProject, cleanScriptUrl);
              if (success) {
                  // alert('Đã gửi dữ liệu sang Google Sheet thành công!');
              } else {
                  alert('Cảnh báo: Không thể lưu sang Google Sheet (Lỗi kết nối Script). Dự án chỉ được lưu trên web này.');
              }
          } catch (e) {
              console.error(e);
              alert('Lỗi kết nối Google Apps Script.');
          }
      }

      // 4. Update State & UI
      setLocalProjects([newProject, ...localProjects]);
      setIsModalOpen(false);
      setIsSaving(false);
      
      // Reset form
      setStep(1);
      setNewProjectData({ 
          name: '', code: '', client: '', location: '', manager: '', 
          budget: 0, capitalSource: 'StateBudget',
          projectGroup: PROJECT_GROUPS[2], 
          constructionType: CONSTRUCTION_TYPES[0], 
          constructionLevel: CONSTRUCTION_LEVELS[2], 
          scale: ''
      });
      setStartDate(new Date().toISOString().split('T')[0]);
      
      alert(`Đã tạo dự án thành công!\nHệ thống tự động sinh ra ${generatedTasks.length} đầu việc theo quy chế ${newProjectData.capitalSource === 'StateBudget' ? '25.10' : '25.20'}.\nNhân sự đã được gán tự động theo RACI.`);
  };

  return (
    <div className="flex-1 bg-gray-50 min-h-screen">
      <Header title="Danh mục Dự án" breadcrumb="Trang chủ / Dự án" />
      
      {/* Hidden File Input for Import */}
      <input 
          type="file" 
          ref={fileInputRef} 
          className="hidden" 
          accept=".csv,.txt" 
          onChange={handleFileChange} 
      />

      {/* --- GOOGLE SHEET MODAL --- */}
      {showSheetModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="p-6 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                      <h3 className="font-bold text-lg text-emerald-800 flex items-center gap-2">
                          <FileSpreadsheet size={20} /> Kết nối Google Sheets
                      </h3>
                      <button onClick={() => setShowSheetModal(false)}><X size={20} className="text-gray-400 hover:text-gray-600"/></button>
                  </div>
                  
                  <div className="p-6 space-y-5 overflow-y-auto custom-scrollbar">
                      <div className="bg-blue-50 p-4 rounded-lg text-xs text-blue-800 leading-relaxed border border-blue-100">
                          <strong>Hướng dẫn nhanh:</strong><br/>
                          1. <b>Read Data:</b> File &gt; Share &gt; Publish to web (CSV).<br/>
                          2. <b>Write Data:</b> Extensions &gt; Apps Script. Dán mã chuẩn và Deploy as Web App (Anyone).
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Sheet ID (Đọc Dữ Liệu)</label>
                          <input 
                              type="text" 
                              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none font-mono"
                              placeholder="VD: 1BxiMVs0XRA5n2He..."
                              value={sheetId}
                              onChange={(e) => setSheetId(e.target.value)}
                          />
                      </div>

                      <div>
                          <label className="block text-xs font-bold text-gray-700 uppercase mb-1">Apps Script URL (Ghi Dữ Liệu)</label>
                          <input 
                              type="text" 
                              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 outline-none font-mono"
                              placeholder="https://script.google.com/macros/s/.../exec"
                              value={scriptUrl}
                              onChange={(e) => setScriptUrl(e.target.value)}
                          />
                          <p className="text-[10px] text-gray-400 mt-1 italic">Để trống nếu bạn chỉ muốn đọc dữ liệu.</p>
                      </div>

                      <div className="pt-2 border-t border-gray-100">
                          <button 
                              onClick={() => setShowScriptCode(!showScriptCode)}
                              className="flex items-center gap-2 text-xs font-bold text-orange-600 hover:text-orange-700 transition-colors"
                          >
                              <Code size={14} /> {showScriptCode ? 'Ẩn mã Script chuẩn' : 'Xem mã Script chuẩn (Copy để tránh lỗi)'}
                          </button>
                          
                          {showScriptCode && (
                              <div className="mt-3 relative group">
                                  <textarea 
                                      readOnly
                                      className="w-full h-40 p-3 bg-slate-900 text-slate-300 text-[10px] font-mono rounded-lg outline-none resize-none custom-scrollbar"
                                      value={STANDARD_SCRIPT}
                                  />
                                  <button 
                                      onClick={() => {navigator.clipboard.writeText(STANDARD_SCRIPT); alert('Đã copy mã!');}}
                                      className="absolute top-2 right-2 p-1.5 bg-white/10 hover:bg-white/20 text-white rounded transition-colors"
                                      title="Copy Code"
                                  >
                                      <Copy size={14} />
                                  </button>
                              </div>
                          )}
                      </div>
                  </div>

                  <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-end gap-2 shrink-0">
                      <button onClick={() => setShowSheetModal(false)} className="px-4 py-2 text-sm font-medium text-gray-600 hover:bg-gray-200 rounded-lg">Hủy</button>
                      <button 
                          onClick={handleSyncSheet} 
                          disabled={isSyncing}
                          className="px-6 py-2 text-sm font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-lg shadow-sm flex items-center gap-2 disabled:opacity-70"
                      >
                          {isSyncing ? <RefreshCw className="animate-spin" size={16} /> : <LinkIcon size={16} />}
                          {isSyncing ? 'Đang kiểm tra...' : 'Lưu & Kết nối'}
                      </button>
                  </div>
              </div>
          </div>
      )}

      {/* --- CREATE PROJECT MODAL --- */}
      {isModalOpen && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm">
              <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col animate-fade-in-up">
                  {/* Modal Header */}
                  <div className="p-6 border-b border-gray-100 bg-gray-50 flex justify-between items-center">
                      <div>
                          <h2 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                              <Sparkles className="text-orange-500 fill-orange-500" size={20} /> Khởi tạo Dự án mới
                          </h2>
                          <p className="text-xs text-gray-500 mt-1">Hệ thống sẽ tự động cấu hình quy trình theo loại vốn</p>
                      </div>
                      <button onClick={() => setIsModalOpen(false)} className="p-2 hover:bg-gray-200 rounded-full text-gray-500">
                          <X size={20} />
                      </button>
                  </div>

                  {/* Wizard Progress */}
                  <div className="w-full bg-gray-100 h-1">
                      <div className={`h-full bg-orange-600 transition-all duration-300 ${step === 1 ? 'w-1/2' : 'w-full'}`}></div>
                  </div>

                  {/* Modal Body */}
                  <div className="p-8 max-h-[70vh] overflow-y-auto custom-scrollbar">
                      {step === 1 ? (
                          <div className="space-y-5">
                              <div className="grid grid-cols-2 gap-5">
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Mã Dự án</label>
                                      <input 
                                          type="text" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          placeholder="VD: 25015"
                                          value={newProjectData.code}
                                          onChange={e => setNewProjectData({...newProjectData, code: e.target.value})}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Nguồn vốn (Quy chế áp dụng)</label>
                                      <select 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none bg-white"
                                          value={newProjectData.capitalSource}
                                          onChange={e => setNewProjectData({...newProjectData, capitalSource: e.target.value as any})}
                                      >
                                          <option value="StateBudget">Vốn Ngân Sách (Quy chế 25.10)</option>
                                          <option value="NonStateBudget">Vốn Ngoài NS (Quy chế 25.20)</option>
                                      </select>
                                  </div>
                              </div>
                              <div>
                                  <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Tên Dự án</label>
                                  <input 
                                      type="text" 
                                      className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                      placeholder="VD: KHU ĐÔ THỊ SINH THÁI..."
                                      value={newProjectData.name}
                                      onChange={e => setNewProjectData({...newProjectData, name: e.target.value})}
                                  />
                              </div>
                              
                              {/* --- NEW FIELDS FOR CLASSIFICATION --- */}
                              <div className="grid grid-cols-2 gap-5">
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Nhóm dự án (Luật ĐTC 58/2024)</label>
                                      <select 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none bg-white"
                                          value={newProjectData.projectGroup}
                                          onChange={e => setNewProjectData({...newProjectData, projectGroup: e.target.value})}
                                      >
                                          {PROJECT_GROUPS.map(g => <option key={g} value={g}>{g}</option>)}
                                      </select>
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Loại công trình (06/2021/TT-BXD)</label>
                                      <select 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none bg-white"
                                          value={newProjectData.constructionType}
                                          onChange={e => setNewProjectData({...newProjectData, constructionType: e.target.value})}
                                      >
                                          {CONSTRUCTION_TYPES.map(t => <option key={t} value={t}>{t}</option>)}
                                      </select>
                                  </div>
                              </div>
                              <div className="grid grid-cols-2 gap-5">
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Cấp công trình</label>
                                      <select 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none bg-white"
                                          value={newProjectData.constructionLevel}
                                          onChange={e => setNewProjectData({...newProjectData, constructionLevel: e.target.value})}
                                      >
                                          {CONSTRUCTION_LEVELS.map(l => <option key={l} value={l}>{l}</option>)}
                                      </select>
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Quy mô (m2 sàn / chiều dài)</label>
                                      <input 
                                          type="text" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          placeholder="VD: 35.000 m2"
                                          value={newProjectData.scale}
                                          onChange={e => setNewProjectData({...newProjectData, scale: e.target.value})}
                                      />
                                  </div>
                              </div>
                              {/* --- END NEW FIELDS --- */}

                              <div className="grid grid-cols-2 gap-5">
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Khách hàng / Đối tác</label>
                                      <input 
                                          type="text" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          placeholder="Tên CĐT..."
                                          value={newProjectData.client}
                                          onChange={e => setNewProjectData({...newProjectData, client: e.target.value})}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Ngày bắt đầu (Dự kiến)</label>
                                      <input 
                                          type="date" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          value={startDate}
                                          onChange={e => setStartDate(e.target.value)}
                                      />
                                  </div>
                              </div>
                              <div className="grid grid-cols-2 gap-5">
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Địa điểm thực hiện</label>
                                      <input 
                                          type="text" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          placeholder="Tỉnh/Thành phố..."
                                          value={newProjectData.location}
                                          onChange={e => setNewProjectData({...newProjectData, location: e.target.value})}
                                      />
                                  </div>
                                  <div>
                                      <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Quản lý dự án (PM)</label>
                                      <input 
                                          type="text" 
                                          className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                          placeholder="Họ và tên..."
                                          value={newProjectData.manager}
                                          onChange={e => setNewProjectData({...newProjectData, manager: e.target.value})}
                                      />
                                  </div>
                              </div>
                              <div>
                                  <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5">Ngân sách dự kiến</label>
                                  <input 
                                      type="number" 
                                      className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none"
                                      placeholder="VNĐ"
                                      value={newProjectData.budget}
                                      onChange={e => setNewProjectData({...newProjectData, budget: parseInt(e.target.value) || 0})}
                                  />
                              </div>
                          </div>
                      ) : (
                          <div className="space-y-6">
                              <div className="bg-orange-50 p-4 rounded-xl border border-orange-100 flex items-start gap-3">
                                  <User className="text-orange-600 shrink-0 mt-0.5" size={18} />
                                  <div className="text-sm text-orange-800">
                                      <p className="font-bold mb-1">Cấu hình Đội ngũ & RACI</p>
                                      <p className="opacity-80 text-xs leading-relaxed">
                                          Hệ thống sẽ tự động gán nhiệm vụ (Tasks) cho các thành viên dưới đây dựa trên Ma trận trách nhiệm (RACI) của quy chế <strong>{newProjectData.capitalSource === 'StateBudget' ? '25.10' : '25.20'}</strong>.
                                      </p>
                                  </div>
                              </div>

                              <div className="grid grid-cols-2 gap-4">
                                  {['GĐTT', 'PGĐTT', 'QLDA', 'QL BIM', 'TNDH', 'Admin'].map((role) => (
                                      <div key={role}>
                                          <label className="block text-xs font-bold text-gray-700 uppercase mb-1.5 flex justify-between">
                                              {role}
                                              <span className="text-gray-400 font-normal normal-case text-[10px]">*Bắt buộc</span>
                                          </label>
                                          <select 
                                              className="w-full p-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 outline-none bg-white"
                                              value={roleMapping[role] || ''}
                                              onChange={(e) => setRoleMapping({...roleMapping, [role]: e.target.value})}
                                          >
                                              <option value="">-- Chọn nhân sự --</option>
                                              {MOCK_USERS.map(u => (
                                                  <option key={u.id} value={u.id}>{u.name} - {u.role}</option>
                                              ))}
                                          </select>
                                      </div>
                                  ))}
                              </div>

                              <div className="pt-4 border-t border-gray-100">
                                  <p className="text-xs font-bold text-gray-500 uppercase mb-2">Xem trước Task tự động:</p>
                                  <div className="flex flex-wrap gap-2">
                                      {PROJECT_TEMPLATES[newProjectData.capitalSource || 'StateBudget'].map(t => (
                                          <span key={t.code} className="text-[10px] bg-gray-100 text-gray-600 px-2 py-1 rounded border border-gray-200">
                                              {t.code} - {t.name}
                                          </span>
                                      ))}
                                      <span className="text-[10px] bg-orange-50 text-orange-600 px-2 py-1 rounded border border-orange-100 font-bold">
                                          +{PROJECT_TEMPLATES[newProjectData.capitalSource || 'StateBudget'].length} Tasks
                                      </span>
                                  </div>
                              </div>
                          </div>
                      )}
                  </div>

                  {/* Modal Footer */}
                  <div className="p-6 border-t border-gray-100 bg-gray-50 flex justify-between">
                      {step === 2 ? (
                          <button 
                              onClick={() => setStep(1)}
                              className="px-6 py-2.5 border border-gray-300 text-gray-700 font-bold rounded-xl hover:bg-white transition-all text-sm"
                          >
                              Quay lại
                          </button>
                      ) : (
                          <div></div> 
                      )}
                      
                      {step === 1 ? (
                          <button 
                              onClick={() => setStep(2)}
                              className="px-6 py-2.5 bg-orange-600 text-white font-bold rounded-xl hover:bg-orange-700 shadow-lg shadow-orange-200 transition-all text-sm flex items-center gap-2"
                          >
                              Tiếp tục <ChevronRight size={16} />
                          </button>
                      ) : (
                          <button 
                              onClick={handleCreateProject}
                              disabled={isSaving}
                              className="px-6 py-2.5 bg-emerald-600 text-white font-bold rounded-xl hover:bg-emerald-700 shadow-lg shadow-emerald-200 transition-all text-sm flex items-center gap-2 disabled:opacity-70"
                          >
                              {isSaving ? <RefreshCw className="animate-spin" size={16}/> : <Check size={16} />}
                              {isSaving ? 'Đang lưu...' : 'Hoàn tất & Tạo Dự án'}
                          </button>
                      )}
                  </div>
              </div>
          </div>
      )}

      <main className="p-8 max-w-[1600px] mx-auto">
        
        {/* Statistics Row */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Tổng dự án</p>
                <div className="flex justify-between items-end">
                    <h2 className="text-3xl font-bold text-gray-800">124</h2>
                    <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded">+12% so với tháng trước</span>
                </div>
            </div>
            <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Đang hoạt động</p>
                <div className="flex justify-between items-end">
                    <h2 className="text-3xl font-bold text-gray-800">45</h2>
                    <span className="text-xs font-medium text-emerald-600 bg-emerald-50 px-2 py-1 rounded">+5 dự án mới</span>
                </div>
            </div>
             <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Đúng tiến độ</p>
                <div className="flex justify-between items-end">
                    <h2 className="text-3xl font-bold text-gray-800">38</h2>
                    <span className="text-xs font-medium text-orange-600 bg-orange-50 px-2 py-1 rounded">84% hoạt động</span>
                </div>
            </div>
             <div className="bg-white p-5 rounded-xl border border-gray-200 shadow-sm">
                <p className="text-sm text-gray-500 mb-1">Chậm tiến độ</p>
                <div className="flex justify-between items-end">
                    <h2 className="text-3xl font-bold text-gray-800">7</h2>
                    <span className="text-xs font-medium text-rose-600 bg-rose-50 px-2 py-1 rounded">-1% cải thiện</span>
                </div>
            </div>
        </div>

        {/* Filters & View Toggle */}
        <div className="bg-white rounded-t-xl border border-gray-200 p-4 flex flex-wrap justify-between items-center gap-4 mb-0.5">
            <div className="flex flex-wrap items-center gap-3">
                {/* Search Input */}
                <div className="relative">
                    <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
                    <input 
                        type="text" 
                        placeholder="Tìm dự án, mã, đối tác..." 
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        className="pl-9 pr-4 py-2 bg-gray-50 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500 w-64 transition-all"
                    />
                </div>

                {/* Status Filter */}
                <div className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                    <Filter size={14} className="text-gray-400" />
                    <select 
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                        className="bg-transparent border-none outline-none text-sm font-medium text-gray-700 cursor-pointer"
                    >
                        <option value="All">Trạng thái: Tất cả</option>
                        <option value={ProjectStatus.PLANNING}>{ProjectStatus.PLANNING}</option>
                        <option value={ProjectStatus.IN_PROGRESS}>{ProjectStatus.IN_PROGRESS}</option>
                        <option value={ProjectStatus.DELAYED}>{ProjectStatus.DELAYED}</option>
                        <option value={ProjectStatus.COMPLETED}>{ProjectStatus.COMPLETED}</option>
                    </select>
                </div>

                {/* Capital/Type Filter */}
                <div className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-700 hover:bg-gray-50 transition-colors">
                    <MapPin size={14} className="text-gray-400" />
                    <select 
                        value={capitalFilter}
                        onChange={(e) => setCapitalFilter(e.target.value)}
                        className="bg-transparent border-none outline-none text-sm font-medium text-gray-700 cursor-pointer"
                    >
                        <option value="All">Nguồn vốn: Tất cả</option>
                        <option value="StateBudget">Ngân sách (25.10)</option>
                        <option value="NonStateBudget">Ngoài NS (25.20)</option>
                    </select>
                </div>
            </div>

            <div className="flex items-center gap-2">
                {/* IMPORT/EXPORT BUTTONS */}
                <div className="flex gap-2 mr-2">
                    <button 
                        onClick={() => setShowSheetModal(true)}
                        className="flex items-center gap-1.5 px-3 py-2 bg-white border border-emerald-200 text-emerald-700 rounded-lg hover:bg-emerald-50 transition-all text-sm font-bold"
                        title="Kết nối Google Sheet"
                    >
                        <FileSpreadsheet size={16} /> <span className="hidden xl:inline">Google Sheet</span>
                    </button>
                    <button 
                        onClick={handleImportClick}
                        className="flex items-center gap-1.5 px-3 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all text-sm font-medium"
                        title="Nhập danh sách từ file CSV"
                    >
                        <Upload size={16} className="text-gray-500" /> <span className="hidden xl:inline">Import</span>
                    </button>
                    
                    <button 
                        onClick={handleExport}
                        className="flex items-center gap-1.5 px-3 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all text-sm font-medium"
                        title="Xuất danh sách ra file Excel/CSV"
                    >
                        <Download size={16} className="text-emerald-600" /> <span className="hidden xl:inline">Export</span>
                    </button>
                </div>

                {/* CREATE PROJECT BUTTON */}
                <button 
                    onClick={() => setIsModalOpen(true)}
                    className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white font-bold rounded-lg shadow-md hover:bg-orange-700 transition-all text-sm"
                >
                    <Plus size={18} /> Tạo Dự án mới
                </button>

                <div className="flex items-center gap-1 border border-gray-200 rounded-lg p-1 bg-gray-50 ml-2">
                    <button 
                        onClick={() => setViewMode('grid')}
                        className={`p-2 rounded transition-all ${viewMode === 'grid' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                        title="Dạng lưới"
                    >
                        <LayoutGrid size={18} />
                    </button>
                     <button 
                        onClick={() => setViewMode('list')}
                        className={`p-2 rounded transition-all ${viewMode === 'list' ? 'bg-white text-orange-600 shadow-sm' : 'text-gray-400 hover:text-gray-600'}`}
                        title="Dạng danh sách"
                    >
                        <List size={18} />
                    </button>
                </div>
            </div>
        </div>

        {/* Content Area */}
        <div className={`transition-opacity duration-300 ${viewMode === 'grid' ? 'bg-transparent' : 'bg-white border-x border-b border-gray-200 rounded-b-xl overflow-hidden shadow-sm'}`}>
            
            {filteredProjects.length === 0 ? (
                <div className="p-12 text-center">
                    <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-400">
                        <SearchIcon size={32} />
                    </div>
                    <h3 className="text-lg font-bold text-gray-800">Không tìm thấy dự án</h3>
                    <p className="text-gray-500">Thử thay đổi bộ lọc hoặc từ khóa tìm kiếm của bạn.</p>
                    <button 
                        onClick={() => { setSearchQuery(''); setStatusFilter('All'); setCapitalFilter('All'); }}
                        className="mt-4 px-4 py-2 text-orange-600 font-medium hover:bg-orange-50 rounded-lg transition-colors"
                    >
                        Xóa bộ lọc
                    </button>
                </div>
            ) : (
                <>
                    {/* GRID / DECK VIEW */}
                    {viewMode === 'grid' && (
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 pt-6">
                            {filteredProjects.map((project) => (
                                <Link to={`/projects/${project.id}`} key={project.id} className="group bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 overflow-hidden flex flex-col">
                                    {/* Card Image */}
                                    <div className="relative h-48 overflow-hidden">
                                        <img 
                                            src={project.thumbnail} 
                                            alt={project.name} 
                                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
                                        />
                                        <div className="absolute top-3 right-3">
                                            <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase tracking-wider shadow-sm backdrop-blur-md
                                                ${project.status === ProjectStatus.IN_PROGRESS ? 'bg-orange-500/90 text-white' : 
                                                project.status === ProjectStatus.PLANNING ? 'bg-gray-500/90 text-white' :
                                                project.status === ProjectStatus.DELAYED ? 'bg-rose-500/90 text-white' : 
                                                'bg-emerald-500/90 text-white'
                                                }`}>
                                                {project.status}
                                            </span>
                                        </div>
                                        <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-black/60 to-transparent"></div>
                                        <div className="absolute bottom-3 left-4 text-white">
                                            <p className="text-[10px] font-mono opacity-80 mb-0.5">{project.code}</p>
                                            <h3 className="font-bold text-lg leading-tight line-clamp-1">{project.name}</h3>
                                        </div>
                                    </div>

                                    {/* Card Body */}
                                    <div className="p-5 flex-1 flex flex-col">
                                        <div className="mb-4 space-y-2">
                                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                                <Building2 size={14} className="text-gray-400 shrink-0" />
                                                <span className="font-medium text-gray-700 truncate">{project.client}</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                                <MapPin size={14} className="text-gray-400 shrink-0" />
                                                <span className="truncate">{project.location || 'Chưa cập nhật'}</span>
                                            </div>
                                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                                <User size={14} className="text-gray-400 shrink-0" />
                                                <span className="truncate">PM: <span className="font-medium text-gray-700">{project.manager || 'Chưa chỉ định'}</span></span>
                                            </div>
                                            <div className="flex items-center gap-2 text-xs text-gray-500">
                                                <Clock size={14} className="text-amber-500 shrink-0" />
                                                <span>Deadline: {project.deadline}</span>
                                            </div>
                                        </div>

                                        <div className="mt-auto pt-3 border-t border-gray-50">
                                            {/* Work Progress Bar */}
                                            <div className="mb-3">
                                                <div className="flex justify-between items-center mb-1">
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase">Tiến độ</span>
                                                    <span className="text-sm font-bold text-orange-600">{project.progress}%</span>
                                                </div>
                                                <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                                                    <div 
                                                        className={`h-full rounded-full transition-all duration-1000 ${project.status === ProjectStatus.DELAYED ? 'bg-rose-500' : 'bg-orange-600'}`} 
                                                        style={{ width: `${project.progress}%` }}
                                                    ></div>
                                                </div>
                                            </div>

                                            {/* Payment Progress Bar */}
                                            <div>
                                                <div className="flex justify-between items-center mb-1">
                                                    <span className="text-[10px] font-bold text-gray-400 uppercase">Thanh toán</span>
                                                    <span className="text-xs font-bold text-emerald-600">
                                                        {project.budget > 0 ? Math.round((project.spent / project.budget) * 100) : 0}%
                                                    </span>
                                                </div>
                                                <div className="w-full bg-gray-100 rounded-full h-1.5 overflow-hidden">
                                                    <div 
                                                        className="h-full rounded-full bg-emerald-500 transition-all duration-1000" 
                                                        style={{ width: `${project.budget > 0 ? (project.spent / project.budget) * 100 : 0}%` }}
                                                    ></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </Link>
                            ))}
                        </div>
                    )}

                    {/* LIST VIEW */}
                    {viewMode === 'list' && (
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="bg-gray-50 text-gray-500 text-xs uppercase font-semibold border-b border-gray-200">
                                <th className="px-6 py-4">Tên & Mã Dự án</th>
                                <th className="px-6 py-4">Trạng thái</th>
                                <th className="px-6 py-4 w-1/4">Tiến độ</th>
                                <th className="px-6 py-4">Các bên liên quan</th>
                                <th className="px-6 py-4 text-right">Thao tác</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-100">
                            {filteredProjects.map((project) => (
                                <tr key={project.id} className="hover:bg-gray-50/50 transition group">
                                    <td className="px-6 py-4">
                                        <Link to={`/projects/${project.id}`} className="flex items-center gap-4 group-hover:opacity-80 transition-opacity">
                                            <img src={project.thumbnail} alt="" className="w-12 h-12 rounded-lg object-cover border border-gray-200 shadow-sm" />
                                            <div>
                                                <h3 className="font-bold text-gray-800 text-sm group-hover:text-orange-600 transition-colors">{project.name}</h3>
                                                <div className="flex gap-2 items-center mt-1">
                                                    <span className="text-xs bg-gray-100 text-gray-600 px-1.5 py-0.5 rounded border border-gray-200 font-mono">
                                                        {project.code}
                                                    </span>
                                                    <span className="text-xs text-gray-500">• {project.client}</span>
                                                </div>
                                                <div className="flex gap-2 items-center mt-1 text-xs text-gray-400">
                                                    <MapPin size={10} /> {project.location || 'N/A'}
                                                </div>
                                            </div>
                                        </Link>
                                    </td>
                                    <td className="px-6 py-4">
                                        <span className={`inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border
                                            ${project.status === ProjectStatus.IN_PROGRESS ? 'bg-orange-50 text-orange-700 border-orange-100' : 
                                            project.status === ProjectStatus.PLANNING ? 'bg-gray-100 text-gray-700 border-gray-200' :
                                            project.status === ProjectStatus.DELAYED ? 'bg-rose-50 text-rose-700 border-rose-100' : 
                                            'bg-emerald-50 text-emerald-700 border-emerald-100'
                                            }`}>
                                            <span className={`w-1.5 h-1.5 rounded-full mr-1.5 
                                                ${project.status === ProjectStatus.IN_PROGRESS ? 'bg-orange-600' : 
                                                project.status === ProjectStatus.PLANNING ? 'bg-gray-500' :
                                                project.status === ProjectStatus.DELAYED ? 'bg-rose-600' : 
                                                'bg-emerald-600'}`}>
                                            </span>
                                            {project.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex justify-between mb-1">
                                            <span className="text-sm font-medium text-gray-700">{project.progress}%</span>
                                            <span className="text-xs text-gray-500">Mục tiêu: 70%</span>
                                        </div>
                                        <div className="w-full bg-gray-100 rounded-full h-2">
                                            <div 
                                                className={`h-2 rounded-full ${project.status === ProjectStatus.DELAYED ? 'bg-rose-500' : 'bg-orange-600'}`} 
                                                style={{ width: `${project.progress}%` }}
                                            ></div>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4">
                                        <div className="flex -space-x-2 overflow-hidden mb-1">
                                            {[...Array(3)].map((_, i) => (
                                                <img 
                                                    key={i} 
                                                    className="inline-block h-8 w-8 rounded-full ring-2 ring-white" 
                                                    src={`https://picsum.photos/id/${100 + i}/100/100`} 
                                                    alt="" 
                                                />
                                            ))}
                                            <div className="h-8 w-8 rounded-full bg-gray-100 ring-2 ring-white flex items-center justify-center text-xs font-medium text-gray-600">
                                                +{project.members}
                                            </div>
                                        </div>
                                        <div className="text-xs text-gray-500">
                                            PM: <span className="font-medium text-gray-700">{project.manager || 'N/A'}</span>
                                        </div>
                                    </td>
                                    <td className="px-6 py-4 text-right">
                                        <button className="p-2 text-gray-400 hover:text-gray-600 rounded-full hover:bg-gray-100">
                                            <MoreHorizontal size={20} />
                                        </button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                    )}
                </>
            )}

             {/* Pagination (Common) */}
             <div className={`px-6 py-4 border-t border-gray-200 flex justify-between items-center bg-gray-50/30 ${viewMode === 'grid' ? 'mt-6 rounded-xl border' : ''}`}>
                <p className="text-sm text-gray-500">Hiển thị {filteredProjects.length} kết quả</p>
                <div className="flex gap-1">
                    <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-600 hover:bg-gray-50">Trước</button>
                    <button className="px-3 py-1 bg-orange-600 text-white rounded text-sm hover:bg-orange-700">1</button>
                    <button className="px-3 py-1 border border-gray-300 rounded text-sm text-gray-600 hover:bg-gray-50">Sau</button>
                </div>
             </div>
        </div>
      </main>
    </div>
  );
};

export default ProjectList;
