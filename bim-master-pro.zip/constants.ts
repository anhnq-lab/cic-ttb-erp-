
import { Project, ProjectStatus, Contract, ContractStatus, Task, KpiMetric, TaskStatus, TaskPriority, PaymentStatus, Employee, Customer, CRMContact, CRMActivity, CRMOpportunity } from './types';

// --- DANH MỤC PHÂN LOẠI DỰ ÁN ---

// Theo Luật Đầu tư công số 58/2024/QH15 (Điều 6, 8, 9, 10, 11)
export const PROJECT_GROUPS = [
    'Quan trọng quốc gia',
    'Nhóm A',
    'Nhóm B',
    'Nhóm C'
];

// Theo Thông tư 06/2021/TT-BXD (Phụ lục I)
export const CONSTRUCTION_TYPES = [
    'Công trình dân dụng',
    'Công trình công nghiệp',
    'Công trình hạ tầng kỹ thuật',
    'Công trình giao thông',
    'Công trình phục vụ nông nghiệp và PTNT',
    'Công trình quốc phòng, an ninh'
];

// Theo Thông tư 06/2021/TT-BXD (Điều 2 & Phụ lục II)
export const CONSTRUCTION_LEVELS = [
    'Cấp đặc biệt',
    'Cấp I',
    'Cấp II',
    'Cấp III',
    'Cấp IV'
];

export const KPIS: KpiMetric[] = [
  { label: 'Doanh thu (YTD)', value: '12.5 tỷ ₫', trend: 12.4, isPositive: true, icon: 'dollar' },
  { label: 'Lợi nhuận ròng', value: '2.3 tỷ ₫', trend: 5.2, isPositive: true, icon: 'trending-up' },
  { label: 'Dòng tiền HĐ', value: '1.8 tỷ ₫', trend: -1.8, isPositive: false, icon: 'activity' },
  { label: 'Nhân sự Active', value: '142', trend: 4, isPositive: true, icon: 'users' },
];

// Helper to generate reliable avatar
const getAvatar = (name: string) => `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=random&color=fff&size=150`;
const getLogo = (name: string) => `https://ui-avatars.com/api/?name=${encodeURIComponent(name)}&background=fff&color=333&size=150&font-size=0.33&rounded=true&bold=true`;


export const MOCK_USERS = [
    { id: 'u1', name: 'Nguyễn Hoàng Hà', role: 'GĐTT', avatar: getAvatar('Nguyễn Hoàng Hà') },
    { id: 'u2', name: 'Nguyễn Bá Nhiệm', role: 'PGĐTT/MEP Lead', avatar: getAvatar('Nguyễn Bá Nhiệm') },
    { id: 'u3', name: 'Trần Hữu Hải', role: 'BIM Coordinator', avatar: getAvatar('Trần Hữu Hải') },
    { id: 'u4', name: 'Vũ Ngọc Thủy', role: 'Kiến trúc sư', avatar: getAvatar('Vũ Ngọc Thủy') },
    { id: 'u5', name: 'Nguyễn Đức Thành', role: 'Kỹ sư', avatar: getAvatar('Nguyễn Đức Thành') },
    { id: 'u6', name: 'Lương Thành Hưng', role: 'BIM Manager', avatar: getAvatar('Lương Thành Hưng') },
    { id: 'u7', name: 'Đào Đông Quỳnh', role: 'Admin', avatar: getAvatar('Đào Đông Quỳnh') },
];

export const EMPLOYEES: Employee[] = [
    { 
        id: 'u1', code: 'CIC-001', name: 'Nguyễn Hoàng Hà', role: 'Giám đốc Trung tâm', department: 'Ban Giám Đốc', 
        email: 'ha.nguyen@cic.com.vn', phone: '0901.234.567', avatar: getAvatar('Nguyễn Hoàng Hà'), 
        status: 'Chính thức', joinDate: '2015-01-15', skills: ['Quản lý', 'Chiến lược', 'Chuyên gia BIM'] 
    },
    { 
        id: 'u2', code: 'CIC-002', name: 'Nguyễn Bá Nhiệm', role: 'Phó GĐTT / Trưởng MEP', department: 'Ban Giám Đốc', 
        email: 'nhiem.nguyen@cic.com.vn', phone: '0909.888.777', avatar: getAvatar('Nguyễn Bá Nhiệm'), 
        status: 'Chính thức', joinDate: '2016-03-20', skills: ['Thiết kế MEP', 'Quản lý dự án', 'Revit'] 
    },
    { 
        id: 'u6', code: 'CIC-005', name: 'Lương Thành Hưng', role: 'BIM Manager', department: 'Quản lý Dự án', 
        email: 'hung.luong@cic.com.vn', phone: '0912.345.678', avatar: getAvatar('Lương Thành Hưng'), 
        status: 'Chính thức', joinDate: '2018-06-01', skills: ['Điều phối BIM', 'Navisworks', 'CDE'] 
    },
    { 
        id: 'u3', code: 'CIC-008', name: 'Trần Hữu Hải', role: 'BIM Coordinator', department: 'Kỹ thuật - BIM', 
        email: 'hai.tran@cic.com.vn', phone: '0933.444.555', avatar: getAvatar('Trần Hữu Hải'), 
        status: 'Chính thức', joinDate: '2019-09-10', skills: ['Kiểm tra va chạm', 'Revit API', 'Dynamo'] 
    },
    { 
        id: 'u4', code: 'CIC-012', name: 'Vũ Ngọc Thủy', role: 'KTS Chủ trì', department: 'Kỹ thuật - Kiến trúc', 
        email: 'thuy.vu@cic.com.vn', phone: '0987.654.321', avatar: getAvatar('Vũ Ngọc Thủy'), 
        status: 'Chính thức', joinDate: '2020-02-15', skills: ['Kiến trúc', 'Diễn họa', 'Enscape'] 
    },
    { 
        id: 'u5', code: 'CIC-015', name: 'Nguyễn Đức Thành', role: 'Kỹ sư Kết cấu', department: 'Kỹ thuật - Kết cấu', 
        email: 'thanh.nguyen@cic.com.vn', phone: '0369.852.147', avatar: getAvatar('Nguyễn Đức Thành'), 
        status: 'Chính thức', joinDate: '2021-05-20', skills: ['Tính toán kết cấu', 'Tekla', 'Revit'] 
    },
    { 
        id: 'u7', code: 'CIC-020', name: 'Đào Đông Quỳnh', role: 'Trưởng bộ phận Admin', department: 'Hành chính - Nhân sự', 
        email: 'quynh.dao@cic.com.vn', phone: '0905.123.456', avatar: getAvatar('Đào Đông Quỳnh'), 
        status: 'Chính thức', joinDate: '2022-01-05', skills: ['Nhân sự', 'Kế toán', 'Hành chính'] 
    },
    { 
        id: 'u8', code: 'CIC-025', name: 'Phạm Văn Minh', role: 'Thực tập sinh BIM', department: 'Kỹ thuật - BIM', 
        email: 'minh.pham@cic.com.vn', phone: '0333.999.888', avatar: getAvatar('Phạm Văn Minh'), 
        status: 'Thử việc', joinDate: '2024-03-01', skills: ['Revit Cơ bản', 'AutoCAD'] 
    },
    { 
        id: 'u9', code: 'CIC-022', name: 'Lê Thị Mai', role: 'Kế toán tổng hợp', department: 'Tài chính - Kế toán', 
        email: 'mai.le@cic.com.vn', phone: '0911.222.333', avatar: getAvatar('Lê Thị Mai'), 
        status: 'Nghỉ phép', joinDate: '2019-11-15', skills: ['Kế toán', 'Thuế', 'Báo cáo tài chính'] 
    }
];

export const CUSTOMERS: Customer[] = [
    {
        id: 'CUST-001', code: 'VIG', name: 'Tập đoàn Vingroup - CTCP', shortName: 'VinGroup',
        type: 'Client', category: 'RealEstate', taxCode: '0101234567',
        address: 'Số 7 Đường Bằng Lăng 1, KĐT Vinhomes Riverside, Long Biên, Hà Nội',
        representative: 'Bà Phạm Thị Lan', contactPerson: 'Ông Lê Văn A (Ban QLDA)',
        email: 'info@vingroup.net', phone: '024 3974 9999', website: 'vingroup.net',
        status: 'Active', tier: 'VIP', totalProjectValue: 15200000000,
        logo: getLogo('VinGroup'),
        rating: 5, evaluation: 'Thanh toán đúng hạn, yêu cầu kỹ thuật cao.'
    },
    {
        id: 'CUST-002', code: 'QLDA-DDCN', name: 'Ban QLDA ĐTXD Các công trình Dân dụng & CN', shortName: 'Ban DD&CN',
        type: 'Client', category: 'StateBudget', taxCode: '315584775',
        address: '341 Sư Vạn Hạnh, Phường 10, Quận 10, TP Hồ Chí Minh',
        representative: 'Ông Huỳnh Minh Hùng', contactPerson: 'Ông Nguyễn Phương Đông',
        email: 'banqlda@tphcm.gov.vn', phone: '028 3835 6789',
        status: 'Active', tier: 'Standard', totalProjectValue: 155000000,
        logo: getLogo('Ban QLDA'),
        rating: 4, evaluation: 'Quy trình thủ tục hành chính phức tạp, nhưng uy tín.'
    },
    {
        id: 'CUST-003', code: 'COTECCONS', name: 'Công ty Cổ phần Xây dựng Coteccons', shortName: 'Coteccons',
        type: 'Client', category: 'Construction', taxCode: '0303443233',
        address: 'Tòa nhà Coteccons, 236/6 Điện Biên Phủ, Bình Thạnh, TP.HCM',
        representative: 'Ông Bolat Duisenov', contactPerson: 'Bà Nguyễn Thị B (Phòng Đấu thầu)',
        email: 'contact@coteccons.vn', phone: '028 3514 2255', website: 'coteccons.vn',
        status: 'Active', tier: 'Gold', totalProjectValue: 5400000000,
        logo: getLogo('Coteccons'),
        rating: 5, evaluation: 'Đối tác chiến lược, năng lực thi công mạnh.'
    },
    {
        id: 'CUST-004', code: 'HBC', name: 'Tập đoàn Xây dựng Hòa Bình', shortName: 'Hòa Bình Corp',
        type: 'Client', category: 'Construction', taxCode: '0302495123',
        address: 'Tòa nhà Pax Sky, 123 Nguyễn Đình Chiểu, Quận 3, TP.HCM',
        representative: 'Ông Lê Viết Hải', contactPerson: 'Ông Trần Văn C (GĐ Kỹ thuật)',
        email: 'info@hbcg.vn', phone: '028 3932 5030', website: 'hbcg.vn',
        status: 'Active', tier: 'Gold', totalProjectValue: 3200000000,
        logo: getLogo('Hoa Binh'),
        rating: 4, evaluation: 'Cần theo dõi sát tiến độ phối hợp.'
    },
    {
        id: 'CUST-005', code: 'SUN', name: 'Công ty Cổ phần Tập đoàn Mặt Trời', shortName: 'Sun Group',
        type: 'Client', category: 'RealEstate', taxCode: '0401345678',
        address: 'Tầng 9, Tòa nhà Sun City, 13 Hai Bà Trưng, Hoàn Kiếm, Hà Nội',
        representative: 'Ông Đặng Minh Trường', contactPerson: 'Bà Lê Thị D (Ban Thiết kế)',
        email: 'sungroup@sungroup.com.vn', phone: '024 3938 6666', website: 'sungroup.com.vn',
        status: 'Inactive', tier: 'VIP', totalProjectValue: 8900000000,
        logo: getLogo('Sun Group'),
        rating: 5, evaluation: 'Khách hàng tiềm năng lớn.'
    },
    {
        id: 'CUST-006', code: 'TV-INDOCHINE', name: 'Indochine Engineering', shortName: 'Indochine',
        type: 'Partner', category: 'Consulting', taxCode: '0304892111',
        address: 'Tầng 15, Tòa nhà CJ, Lê Thánh Tôn, Q1, TP.HCM',
        representative: 'Ông David', contactPerson: 'Ông Nguyễn Văn E',
        email: 'info@indochine.vn', phone: '028 3822 9999', website: 'indochine-engineering.com',
        status: 'Active', tier: 'Gold', totalProjectValue: 800000000,
        logo: getLogo('Indochine'),
        rating: 4, evaluation: 'Đối tác thiết kế MEP uy tín.'
    }
];

export const MOCK_CRM_CONTACTS: CRMContact[] = [
    { id: 'ct1', customerId: 'CUST-001', name: 'Ông Lê Văn A', position: 'Giám đốc Ban QLDA', email: 'a.le@vingroup.net', phone: '0909111222', isPrimary: true },
    { id: 'ct2', customerId: 'CUST-001', name: 'Bà Trần Thị B', position: 'Kế toán trưởng', email: 'b.tran@vingroup.net', phone: '0909333444', isPrimary: false },
    { id: 'ct3', customerId: 'CUST-002', name: 'Ông Nguyễn Phương Đông', position: 'Chuyên viên', email: 'dong.np@tphcm.gov.vn', phone: '0912345678', isPrimary: true },
];

export const MOCK_CRM_ACTIVITIES: CRMActivity[] = [
    { id: 'act1', customerId: 'CUST-001', type: 'Meeting', date: '2025-03-20', title: 'Họp giao ban tuần', description: 'Thống nhất phương án thiết kế Concept tòa A.', createdBy: 'Nguyễn Bá Nhiệm' },
    { id: 'act2', customerId: 'CUST-001', type: 'Email', date: '2025-03-18', title: 'Gửi hồ sơ năng lực', description: 'Đã gửi profile cập nhật mới nhất cho chị Lan.', createdBy: 'Nguyễn Quốc Anh' },
    { id: 'act3', customerId: 'CUST-001', type: 'Call', date: '2025-03-15', title: 'Trao đổi về Hợp đồng', description: 'Khách hàng yêu cầu giảm 2% giá trị gói thầu.', createdBy: 'Nguyễn Hoàng Hà' },
    { id: 'act4', customerId: 'CUST-003', type: 'Meal', date: '2025-03-10', title: 'Ăn trưa thân mật', description: 'Gặp gỡ anh Hùng bên Coteccons bàn về dự án mới.', createdBy: 'Nguyễn Hoàng Hà' },
];

export const MOCK_CRM_OPPORTUNITIES: CRMOpportunity[] = [
    { id: 'opp1', customerId: 'CUST-001', name: 'BIM cho Vinhomes Cổ Loa', value: 5500000000, stage: 'Negotiation', probability: 80, expectedCloseDate: '2025-05-30' },
    { id: 'opp2', customerId: 'CUST-003', name: 'Phối hợp MEP dự án Lego', value: 1200000000, stage: 'Proposal', probability: 40, expectedCloseDate: '2025-06-15' },
];

// TEMPLATES for Auto-Generation based on Policy 25.10 & 25.20
export const PROJECT_TEMPLATES = {
    StateBudget: [
        { code: '1.1', name: 'Thuyết trình khách hàng (Vốn NS)', offset: 0, duration: 3, assigneeRole: 'QL BIM', priority: TaskPriority.HIGH },
        { code: '1.4', name: 'Thu thập dữ liệu đầu vào báo giá', offset: 2, duration: 5, assigneeRole: 'QLDA', priority: TaskPriority.MEDIUM },
        { code: '2.5', name: 'Lập báo giá & Hồ sơ thầu', offset: 7, duration: 5, assigneeRole: 'GĐTT', priority: TaskPriority.HIGH },
        { code: '3.1', name: 'Quyết định bổ nhiệm nhân sự (QĐ-01)', offset: 12, duration: 1, assigneeRole: 'GĐTT', priority: TaskPriority.HIGH },
        { code: '3.4', name: 'Thiết lập môi trường CDE & Bimcollab', offset: 13, duration: 2, assigneeRole: 'QL BIM', priority: TaskPriority.HIGH },
        { code: '4.1', name: 'Dựng mô hình trình thẩm định (LOD 300)', offset: 15, duration: 14, assigneeRole: 'TNDH', priority: TaskPriority.HIGH },
        { code: '4.4', name: 'Tập hợp hồ sơ trình thẩm định', offset: 29, duration: 3, assigneeRole: 'QLDA', priority: TaskPriority.HIGH },
    ],
    NonStateBudget: [
        { code: '1.1', name: 'Thuyết trình giải pháp (Tư nhân)', offset: 0, duration: 2, assigneeRole: 'QL BIM', priority: TaskPriority.HIGH },
        { code: '2.2', name: 'Chốt khối lượng & Scope', offset: 3, duration: 4, assigneeRole: 'PGĐTT', priority: TaskPriority.HIGH },
        { code: '2.4', name: 'Lập Pre-BEP', offset: 5, duration: 3, assigneeRole: 'QL BIM', priority: TaskPriority.MEDIUM },
        { code: '3.6', name: 'Tạo Template dự án (Theo chuẩn CĐT)', offset: 8, duration: 3, assigneeRole: 'PGĐTT', priority: TaskPriority.MEDIUM },
        { code: '4.1', name: 'Dựng mô hình thiết kế kỹ thuật', offset: 12, duration: 20, assigneeRole: 'TNDH', priority: TaskPriority.HIGH },
        { code: '5.1', name: 'Hồ sơ thanh toán đợt 1', offset: 32, duration: 5, assigneeRole: 'Admin', priority: TaskPriority.HIGH },
    ]
};

export const PROJECTS: Project[] = [
  {
    id: 'ND1-4B',
    code: '25010',
    name: '25010-NHIDONG1_4B_BIM',
    client: 'Ban QLDA Dân dụng & Công nghiệp TP.HCM',
    location: 'TP. Hồ Chí Minh',
    manager: 'Nguyễn Quốc Anh',
    
    // New Fields
    projectGroup: 'Nhóm B', // Vốn 155 tỷ < 2.300 tỷ (Y tế) => Nhóm B
    constructionType: 'Công trình dân dụng',
    constructionLevel: 'Cấp I',
    scale: '35.000 m2 sàn',

    capitalSource: 'StateBudget',
    status: ProjectStatus.IN_PROGRESS,
    progress: 15,
    budget: 155000000,
    spent: 0,
    deadline: '2025-04-26',
    members: 5,
    thumbnail: 'https://picsum.photos/id/122/400/300',
  },
  {
    id: '1',
    code: '23001',
    name: '23001-SKYLINE_VIN_INT',
    client: 'Tập đoàn Vingroup - CTCP',
    location: 'Hà Nội',
    manager: 'Nguyễn Hoàng Hà',

    // New Fields
    projectGroup: 'Nhóm A', // Vốn 4.200 tỷ > 2.300 tỷ (Nhà ở) => Nhóm A
    constructionType: 'Công trình dân dụng',
    constructionLevel: 'Cấp đặc biệt',
    scale: '5 tháp 40 tầng',

    capitalSource: 'NonStateBudget',
    status: ProjectStatus.IN_PROGRESS,
    progress: 65,
    budget: 4200000000,
    spent: 2100000000,
    deadline: '2024-12-20',
    members: 12,
    thumbnail: 'https://picsum.photos/id/48/200/200',
  }
];

export const CONTRACTS: Contract[] = [
  {
    id: 'C-ND1',
    code: '30/2025/HĐ-DDCN',
    signedDate: '20/03/2025',
    packageName: 'Tư vấn lập mô hình thông tin công trình (BIM)',
    projectName: 'Xây dựng mới Trung tâm chuyên sâu bệnh nhiệt đới (Khối 4B) Bệnh viện Nhi đồng 1',
    location: '341 Sư Vạn Hạnh, Phường 10, Quận 10, TP Hồ Chí Minh',
    contractType: 'Trọn gói',
    lawApplied: 'Luật Việt Nam',
    
    sideAName: 'Ban Quản lý dự án đầu tư xây dựng các công trình dân dụng và công nghiệp',
    sideARep: 'Ông Huỳnh Minh Hùng',
    sideAPosition: 'Phó Giám đốc',
    sideAMst: '315584775',
    sideAStaff: 'Ông Nguyễn Phương Đông (Chuyên viên Ban điều hành dự án 2)',

    sideBName: 'Công ty Cổ phần Công nghệ và Tư vấn CIC',
    sideBRep: 'Ông Nguyễn Hoàng Hà',
    sideBPosition: 'Tổng giám đốc',
    sideBMst: '0100775353',
    sideBBank: '1200014777 tại BIDV - Chi nhánh Sở giao dịch 1, Hà Nội',

    totalValue: 155000000,
    vatIncluded: true,
    advancePayment: 0,
    paymentMilestones: [
      { 
        id: 'M1',
        phase: 'Đợt 1', 
        condition: 'Thanh toán 90% giá trị quyết toán sau khi ký biên bản nghiệm thu lần 2 và đủ hồ sơ', 
        percentage: 90,
        amount: 139500000,
        dueDate: '2025-04-30',
        status: PaymentStatus.PENDING
      },
      { 
        id: 'M2',
        phase: 'Đợt 2', 
        condition: 'Thanh toán giá trị còn lại sau khi có quyết định phê duyệt quyết toán dự án hoàn thành', 
        percentage: 10,
        amount: 15500000,
        dueDate: '2025-06-30',
        status: PaymentStatus.PENDING
      }
    ],

    duration: '45 ngày (kể cả ngày lễ, tết)',
    startDate: '13/03/2025',
    endDate: '26/04/2025',
    warrantyPeriod: '365 ngày kể từ ngày nghiệm thu bàn giao',

    mainTasks: ['Lập mô hình BIM (Kiến trúc, Kết cấu, MEP)', 'Xử lý va chạm', 'Xuất khối lượng & bản vẽ 2D'],
    fileFormats: 'Định dạng gốc và định dạng chuẩn IFC 4.0',
    deliveryMethod: '01 USB lưu trữ chứa tệp tin BIM đã hoàn thiện',
    acceptanceStandard: 'Được Chủ đầu tư chấp thuận và cơ quan có thẩm quyền thẩm định',

    personnel: [
      { role: 'Quản lý BIM', name: 'Ông Lương Thành Hưng' },
      { role: 'Điều phối BIM', name: 'Ông Trần Hữu Hải' },
      { role: 'Dựng hình BIM (MEP)', name: 'Ông Nguyễn Bá Nhiệm' },
      { role: 'Dựng hình BIM (XD)', name: 'Ông Nguyễn Đức Thành' },
      { role: 'Dựng hình BIM (KT)', name: 'Bà Vũ Ngọc Thủy' }
    ],

    penaltyRate: '0,1% giá hợp đồng cho mỗi ngày chậm',
    maxPenalty: '12% giá trị hợp đồng',
    disputeResolution: 'Tòa án kinh tế cấp có thẩm quyền',

    paidValue: 0,
    remainingValue: 155000000,
    wipValue: 45000000,
    status: ContractStatus.ACTIVE,
    transactions: []
  },
  {
    id: 'C-VIG-01',
    code: '01/2024/VIG-CIC',
    signedDate: '15/01/2024',
    packageName: 'Tư vấn BIM cấp độ 2 dự án Skyline',
    projectName: 'Skyline Residential - VinGroup',
    location: 'Hà Nội',
    contractType: 'Theo đơn giá cố định',
    lawApplied: 'Luật Việt Nam',
    
    sideAName: 'Tập đoàn Vingroup - CTCP',
    sideARep: 'Bà Phạm Thị Lan',
    sideAPosition: 'Giám đốc Ban QLDA',
    sideAMst: '0101234567',
    sideAStaff: 'Ông Lê Văn A',

    sideBName: 'Công ty Cổ phần Công nghệ và Tư vấn CIC',
    sideBRep: 'Ông Nguyễn Hoàng Hà',
    sideBPosition: 'Tổng giám đốc',
    sideBMst: '0100775353',
    sideBBank: '1200014777 tại BIDV',

    totalValue: 4200000000,
    vatIncluded: true,
    advancePayment: 840000000,
    paymentMilestones: [
        { id: 'M1', phase: 'Tạm ứng', condition: 'Ngay sau khi ký hợp đồng', percentage: 20, amount: 840000000, dueDate: '2024-01-20', status: PaymentStatus.PAID, invoiceDate: '2024-01-18' },
        { id: 'M2', phase: 'Đợt 1', condition: 'Hoàn thành mô hình LOD 300', percentage: 30, amount: 1260000000, dueDate: '2024-06-15', status: PaymentStatus.PAID, invoiceDate: '2024-06-10' },
        { id: 'M3', phase: 'Đợt 2', condition: 'Hoàn thành mô hình LOD 400 & Shopdrawing', percentage: 40, amount: 1680000000, dueDate: '2024-11-30', status: PaymentStatus.INVOICED, invoiceDate: '2024-11-25' },
        { id: 'M4', phase: 'Quyết toán', condition: 'Bàn giao và Nghiệm thu toàn bộ', percentage: 10, amount: 420000000, dueDate: '2024-12-31', status: PaymentStatus.PENDING }
    ],

    duration: '12 tháng',
    startDate: '15/01/2024',
    endDate: '15/01/2025',
    warrantyPeriod: '12 tháng',

    mainTasks: ['Lập BEP', 'Dựng mô hình', 'Phối hợp 3D', 'Xuất bản vẽ'],
    fileFormats: 'RVT, PDF, NWC',
    deliveryMethod: 'Bimcollab & CDE',
    acceptanceStandard: 'Theo BEP đã duyệt',

    personnel: [],

    penaltyRate: '0.05%',
    maxPenalty: '8%',
    disputeResolution: 'VIAC',

    paidValue: 2100000000,
    remainingValue: 2100000000,
    wipValue: 1680000000,
    status: ContractStatus.ACTIVE,
    transactions: [
        { id: 'TRX-001', date: '20/01/2024', amount: 840000000, description: 'Thanh toán tạm ứng HĐ 01/2024', method: 'Bank Transfer', invoiceNumber: 'INV-001', status: 'Completed' },
        { id: 'TRX-002', date: '20/06/2024', amount: 1260000000, description: 'Thanh toán đợt 1 HĐ 01/2024', method: 'Bank Transfer', invoiceNumber: 'INV-005', status: 'Completed' }
    ]
  }
];

export const TASKS: Task[] = [
  // ND1-4B Project Tasks
  {
    id: 'T-001',
    code: '40.10.15.01', // [GiaiDoan].[Loai].[BoMon].[STT]
    name: 'Dựng mô hình Kiến trúc Tầng 1',
    projectId: 'ND1-4B',
    assignee: { name: 'Vũ Ngọc Thủy', avatar: getAvatar('Vũ Ngọc Thủy'), role: 'Modeler' },
    reviewer: 'Trần Hữu Hải',
    status: TaskStatus.S4,
    priority: TaskPriority.HIGH,
    startDate: '2025-03-15',
    dueDate: '2025-03-20',
    progress: 100,
    tags: ['ARC', 'LOD300']
  },
  {
    id: 'T-002',
    code: '40.10.15.02',
    name: 'Dựng mô hình Kiến trúc Tầng 2',
    projectId: 'ND1-4B',
    assignee: { name: 'Vũ Ngọc Thủy', avatar: getAvatar('Vũ Ngọc Thủy'), role: 'Modeler' },
    reviewer: 'Trần Hữu Hải',
    status: TaskStatus.S0,
    priority: TaskPriority.MEDIUM,
    startDate: '2025-03-21',
    dueDate: '2025-03-25',
    progress: 45,
    tags: ['ARC', 'LOD300']
  },
  {
    id: 'T-003',
    code: '40.10.10.01',
    name: 'Dựng mô hình Kết cấu Móng',
    projectId: 'ND1-4B',
    assignee: { name: 'Nguyễn Đức Thành', avatar: getAvatar('Nguyễn Đức Thành'), role: 'Modeler' },
    reviewer: 'Trần Hữu Hải',
    status: TaskStatus.S6,
    priority: TaskPriority.HIGH,
    startDate: '2025-03-13',
    dueDate: '2025-03-18',
    progress: 100,
    tags: ['STR', 'LOD350']
  },
  {
    id: 'T-004',
    code: '40.10.30.01',
    name: 'Dựng mô hình HVAC Tầng hầm',
    projectId: 'ND1-4B',
    assignee: { name: 'Nguyễn Bá Nhiệm', avatar: getAvatar('Nguyễn Bá Nhiệm'), role: 'Modeler' },
    reviewer: 'Trần Hữu Hải',
    status: TaskStatus.S1,
    priority: TaskPriority.HIGH,
    startDate: '2025-03-20',
    dueDate: '2025-03-28',
    progress: 30,
    tags: ['MEP', 'HVAC']
  },
  {
    id: 'T-005',
    code: '40.30.99.01',
    name: 'Phối hợp va chạm (Clash Detection) Lần 1',
    projectId: 'ND1-4B',
    assignee: { name: 'Trần Hữu Hải', avatar: getAvatar('Trần Hữu Hải'), role: 'Coordinator' },
    status: TaskStatus.OPEN,
    priority: TaskPriority.MEDIUM,
    startDate: '2025-03-29',
    dueDate: '2025-03-30',
    progress: 0,
    tags: ['Coordination']
  }
];

export const REVENUE_DATA = [
  { name: 'T1', revenue: 400000000, expenses: 240000000 },
  { name: 'T2', revenue: 300000000, expenses: 139800000 },
  { name: 'T3', revenue: 200000000, expenses: 980000000 },
  { name: 'T4', revenue: 278000000, expenses: 390800000 },
  { name: 'T5', revenue: 189000000, expenses: 480000000 },
  { name: 'T6', revenue: 239000000, expenses: 380000000 },
];

export const CASHFLOW_DATA = [
    { name: 'T1', plan: 800000000, actual: 840000000 },
    { name: 'T2', plan: 200000000, actual: 150000000 },
    { name: 'T3', plan: 450000000, actual: 400000000 },
    { name: 'T4', plan: 600000000, actual: 300000000 },
    { name: 'T5', plan: 500000000, actual: 550000000 },
    { name: 'T6', plan: 1200000000, actual: 1260000000 },
    { name: 'T7', plan: 300000000, actual: 0 },
    { name: 'T8', plan: 400000000, actual: 0 },
    { name: 'T9', plan: 250000000, actual: 0 },
    { name: 'T10', plan: 800000000, actual: 0 },
    { name: 'T11', plan: 1600000000, actual: 0 },
    { name: 'T12', plan: 500000000, actual: 0 },
];

export const RESOURCE_DATA = [
  { name: 'Tính phí', value: 75, fill: '#3b82f6' },
  { name: 'Nội bộ', value: 25, fill: '#e2e8f0' },
];
