
export enum ProjectStatus {
  PLANNING = 'Lập kế hoạch',
  IN_PROGRESS = 'Đang thực hiện',
  DELAYED = 'Tạm hoãn',
  COMPLETED = 'Hoàn thành'
}

export enum ContractStatus {
  DRAFT = 'Nháp',
  ACTIVE = 'Hiệu lực',
  PENDING_PAYMENT = 'Chờ thanh toán',
  COMPLETED = 'Hoàn thành',
  OVERDUE = 'Quá hạn'
}

export enum PaymentStatus {
  PENDING = 'Chưa thanh toán',
  INVOICED = 'Đã xuất hóa đơn',
  PAID = 'Đã thanh toán',
  OVERDUE = 'Quá hạn',
  PARTIAL = 'Thanh toán 1 phần'
}

// Based on Policy 40.20.4
export enum TaskStatus {
  OPEN = 'Mở',
  PENDING = 'Đang chờ',
  S0 = 'S0 Đang thực hiện', // Đang triển khai
  S1 = 'S1 Phối hợp', // Phối hợp
  S3 = 'S3 Duyệt nội bộ', // Kiểm tra nội bộ
  S4 = 'S4 Lãnh đạo duyệt', // Lãnh đạo duyệt
  S4_1 = 'S4.1 Sửa theo LĐ', // Sửa theo comment CIC
  S5 = 'S5 Đã duyệt', // Đã duyệt nội bộ
  S6 = 'S6 Trình khách hàng', // Trình khách hàng
  S6_1 = 'S6.1 Sửa theo KH', // Sửa theo comment KH
  COMPLETED = 'Hoàn thành' // Hoàn thành/Đóng
}

export enum TaskPriority {
  HIGH = 'Cao',
  MEDIUM = 'Trung bình',
  LOW = 'Thấp'
}

export interface Project {
  id: string;
  code: string;
  name: string;
  client: string;
  location: string;
  manager: string;
  
  // Technical Fields (Based on Law 58/2024/QH15 & Circular 06/2021/TT-BXD)
  projectGroup?: string; // Quan trọng quốc gia, Nhóm A, B, C
  constructionType?: string; // Dân dụng, Công nghiệp...
  constructionLevel?: string; // Đặc biệt, I, II, III, IV
  scale?: string; // Quy mô (m2 sàn, chiều dài tuyến...)

  capitalSource: 'StateBudget' | 'NonStateBudget';
  status: ProjectStatus;
  progress: number;
  budget: number;
  spent: number;
  deadline: string;
  members: number;
  thumbnail: string;
}

export interface PaymentTransaction {
  id: string;
  date: string;
  amount: number;
  description: string;
  method: 'Bank Transfer' | 'Cash';
  invoiceNumber?: string;
  status: 'Completed' | 'Pending';
}

export interface Contract {
  id: string;
  code: string;
  signedDate: string;
  packageName: string;
  projectName: string;
  location: string;
  contractType: string;
  lawApplied: string;
  
  // Side A
  sideAName: string;
  sideARep: string;
  sideAPosition: string;
  sideAMst: string;
  sideAStaff: string;

  // Side B
  sideBName: string;
  sideBRep: string;
  sideBPosition: string;
  sideBMst: string;
  sideBBank: string;

  // Finance
  totalValue: number;
  vatIncluded: boolean;
  advancePayment: number;
  paymentMilestones: {
    id: string;
    phase: string;
    condition: string;
    percentage: number;
    amount: number;
    dueDate: string;
    status: PaymentStatus;
    invoiceDate?: string;
  }[];

  // Schedule
  duration: string;
  startDate: string;
  endDate: string;
  warrantyPeriod: string;

  // Scope
  mainTasks: string[];
  fileFormats: string;
  deliveryMethod: string;
  acceptanceStandard: string;

  // Key Personnel
  personnel: {
    role: string;
    name: string;
  }[];

  // Legal
  penaltyRate: string;
  maxPenalty: string;
  disputeResolution: string;

  paidValue: number;
  remainingValue: number;
  wipValue: number;
  status: ContractStatus;
  transactions?: PaymentTransaction[]; // History of actual payments
}

export interface Task {
  id: string;
  code: string; // [GiaiDoan].[Loai].[BoMon].[STT]
  name: string;
  projectId: string;
  assignee: {
    name: string;
    avatar: string;
    role: 'Modeler' | 'Leader' | 'Coordinator' | 'Staff' | 'Manager' | string;
  };
  reviewer?: string; // Người kiểm tra (Policy 20.30)
  status: TaskStatus;
  priority: TaskPriority;
  startDate: string;
  dueDate: string;
  progress: number;
  tags?: string[];
}

export interface Employee {
  id: string;
  code: string;
  name: string;
  role: string;
  department: string;
  email: string;
  phone: string;
  avatar: string;
  status: 'Chính thức' | 'Nghỉ phép' | 'Thử việc';
  joinDate: string;
  skills: string[];
}

export interface KpiMetric {
  label: string;
  value: string;
  trend: number;
  isPositive: boolean;
  icon: string;
}

export type CustomerType = 'Client' | 'Partner' | 'Subcontractor';
export type CustomerCategory = 'RealEstate' | 'StateBudget' | 'Consulting' | 'Construction' | 'Other';

export interface Customer {
  id: string;
  code: string;
  name: string;
  shortName: string;
  type: CustomerType;
  category: CustomerCategory;
  taxCode: string;
  address: string;
  representative: string; // Người đại diện pháp luật
  contactPerson: string; // Người liên hệ chính
  email: string;
  phone: string;
  website?: string;
  bankAccount?: string;
  bankName?: string;
  status: 'Active' | 'Inactive';
  tier: 'VIP' | 'Gold' | 'Standard'; // Phân hạng
  totalProjectValue: number; // Tổng giá trị dự án đã hợp tác
  logo: string;
  rating?: number; // 1-5 stars
  evaluation?: string; // Short note on reliability
}

// CRM Extensions
export interface CRMContact {
  id: string;
  customerId: string;
  name: string;
  position: string;
  email: string;
  phone: string;
  isPrimary: boolean;
}

export interface CRMActivity {
  id: string;
  customerId: string;
  type: 'Meeting' | 'Call' | 'Email' | 'Meal' | 'Note';
  date: string;
  title: string;
  description: string;
  createdBy: string;
}

export interface CRMOpportunity {
  id: string;
  customerId: string;
  name: string;
  value: number;
  stage: 'New' | 'Qualification' | 'Proposal' | 'Negotiation' | 'Won' | 'Lost';
  probability: number; // %
  expectedCloseDate: string;
}
