
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import ProjectList from './pages/ProjectList';
import ContractList from './pages/ContractList';
import PolicyViewer from './pages/PolicyViewer';
import ProjectDetail from './pages/ProjectDetail';
import HRMList from './pages/HRMList';
import CRMList from './pages/CRMList';

const App = () => {
  return (
    <Router>
      <div className="flex min-h-screen font-sans bg-gray-50 text-slate-900">
        <Sidebar />
        <div className="ml-64 flex-1 flex flex-col min-h-screen transition-all duration-300">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/projects" element={<ProjectList />} />
            <Route path="/projects/:id" element={<ProjectDetail />} />
            <Route path="/contracts" element={<ContractList />} />
            <Route path="/hr" element={<HRMList />} />
            <Route path="/crm" element={<CRMList />} />
            <Route path="/policy" element={<PolicyViewer />} />
            {/* Redirects/Placeholders for demo completeness */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
};

export default App;
